import{u as ye,c as _e,a as ve,r as d,d as Ne,b as p,j as e}from"./index-Cn6DFgxh.js";import{B}from"./Button-DbIH54Da.js";/* empty css                      */import{F as we,a as je,h as Ie}from"./itemLookup-B-tAzo2_.js";import{F as X}from"./PlusIcon-Cy10Ib0F.js";const Se="http://localhost:4000/api/items",C="http://localhost:4000/api/purchases",j="http://localhost:4000/api/purchase-items",ke=()=>{const I=ye(),{id:_}=_e(),{showAlert:m}=ve(),v=d.useRef(null),Y=d.useRef(null),Z=d.useRef(null),[A,J]=d.useState(!1),[ee,E]=d.useState(!1),[b,Ce]=d.useState(!!_),[N,T]=d.useState(!1),[L,P]=d.useState(""),[k,U]=d.useState(new Date().toISOString().split("T")[0]),[F,M]=d.useState(""),[Fe,te]=d.useState([]),[l,q]=d.useState([]),[R,S]=d.useState(""),[$,V]=d.useState(null),[s,u]=d.useState({item_id:0,item_name:"",item_code:"",quantity:1,rate:0,amount:0,gst_percentage:0,gst_amount:0,transport_charge:0,other_charge:0,total:0,per_item_cost:0}),[z,re]=d.useState(0),[Q,ae]=d.useState(0),[D,se]=d.useState(0),oe=["Vendor 1","Vendor 2","Vendor 3","ABC Trading","XYZ Suppliers"],[ne,w]=d.useState(""),[G,H]=d.useState(!1),ie=()=>{J(!A)};d.useEffect(()=>{de(),(async()=>{b||await ce()})(),b&&_&&le(_)},[b,_]);const K=Ne();d.useEffect(()=>{const r=new URLSearchParams(K.search).get("newItemCode");r&&(S(r),(async()=>{try{const o=await p.get("http://168.231.122.33:4000/api/item-exact",{params:{code:r.trim()}});o.data&&o.data.item&&(O(o.data.item),v.current&&v.current.focus())}catch(o){console.error("Error fetching new item:",o),m("Error fetching the newly added item","error")}})(),I("/forms/purchase-form",{replace:!0}))},[K]);const ce=async()=>{if(!b)try{const a=((await p.get(C)).data||[]).map(x=>x.invoice_number).filter(x=>/^p-\d+$/i.test(x)).map(x=>{const g=x.match(/^p-(\d+)$/i);return g?parseInt(g[1],10):0}),n=`p-${(a.length>0?Math.max(...a):0)+1}`;P(n)}catch(t){console.error("Error generating invoice number:",t),P("p-1")}},de=async()=>{E(!0);try{const r=(await p.get(Se)).data.map(a=>(a.item_code!==void 0&&a.item_code!==null&&(a.item_code=a.item_code.toString().trim()),a));te(r),console.log(`Loaded ${r.length} items from backend API`)}catch(t){console.error("Error loading items:",t),m("Failed to load items from server","error")}finally{E(!1)}},le=async t=>{E(!0);try{const a=(await p.get(`${C}/${t}`)).data;P(a.invoice_number),U(a.invoice_date),M(a.vendor_name);const c=(await p.get(`${j}?purchase_id=${t}`)).data.map(n=>({id:n.id,item_id:n.item_id,item_code:n.item_code||"",item_name:n.item_name,quantity:n.quantity,rate:n.rate,amount:n.amount,gst_percentage:n.gst_percentage||0,gst_amount:n.gst_amount||0,transport_charge:n.transport_charge||0,other_charge:n.other_charge||0,total:n.amount+(n.gst_amount||0)+(n.transport_charge||0)+(n.other_charge||0),per_item_cost:(n.amount+(n.gst_amount||0)+(n.transport_charge||0)+(n.other_charge||0))/n.quantity}));q(c)}catch(r){console.error("Error fetching purchase for editing:",r),m("Failed to load purchase data","error"),I("/lists/purchase-list")}finally{E(!1)}};d.useEffect(()=>{const t=l.reduce((o,c)=>o+c.amount,0),r=l.reduce((o,c)=>o+c.gst_amount,0),a=l.reduce((o,c)=>o+(c.total||0),0);re(t),ae(r),se(a)},[l]);const h=t=>Number.isInteger(t)?t.toString():t.toFixed(2),me=async t=>{const r=t.target.value.trim();if(S(r),r===""){u({item_id:0,item_name:"",item_code:"",quantity:1,rate:0,amount:0,gst_percentage:0,gst_amount:0,transport_charge:0,other_charge:0,total:0,per_item_cost:0});return}try{const a=await p.get("http://168.231.122.33:4000/api/item-exact",{params:{code:r}});a.data&&a.data.item&&(console.log("Item found while typing:",a.data.item.item_name),O(a.data.item))}catch{console.log("No exact match found while typing"),u({item_id:0,item_name:"",item_code:r,quantity:1,rate:0,amount:0,gst_percentage:0,gst_amount:0,transport_charge:0,other_charge:0,total:0,per_item_cost:0})}},ue=t=>{Ie(t,R,r=>{var a;console.log("Exact match found on Tab/Enter:",r.item.item_name),O(r.item),t.key==="Enter"&&((a=document.getElementById("add-item-button"))==null||a.click())},r=>{console.error("Error in exact item lookup:",r),m("Item not found with this exact code","error"),u({item_id:0,item_name:"",item_code:R,quantity:1,rate:0,amount:0,gst_percentage:0,gst_amount:0,transport_charge:0,other_charge:0,total:0,per_item_cost:0})})};d.useEffect(()=>{if(s.item_id&&!G){console.log("Auto recalculating fields");const t=s.quantity,r=s.rate,a=t*r,o=a*(s.gst_percentage/100),c=s.transport_charge||0,n=s.other_charge||0,x=a+o+c+n,g=t>0?x/t:0;w(a.toFixed(2)),u(f=>({...f,amount:a,gst_amount:o,total:x,per_item_cost:g}))}},[s.quantity,s.rate,s.gst_percentage,s.transport_charge,s.other_charge,G]);const O=t=>{const r=parseFloat(t.opening_cost)||0,a=r;w(a.toFixed(2)),u({item_id:t.id,item_name:t.item_name,item_code:t.item_code||"",quantity:1,rate:r,amount:a,gst_percentage:t.gst_percentage||0,gst_amount:0,transport_charge:0,other_charge:0,total:a,per_item_cost:r})},W=t=>{if(!isNaN(t)&&s.item_id){const r=s.quantity||1,a=r>0?t/r:0,o=t*(s.gst_percentage/100),c=s.transport_charge||0,n=s.other_charge||0,x=t+o+c+n,g=r>0?x/r:0;u(f=>({...f,amount:t,rate:a,gst_amount:o,total:x,per_item_cost:g}))}},pe=()=>{w("9622.80"),W(9622.8)},ge=()=>{if(s.item_id===0){m("Please select an item","error");return}if(s.quantity<=0){m("Quantity must be greater than zero","error");return}if(s.rate<=0){m("Rate must be greater than zero","error");return}const t=s.quantity,r=s.total||0,a=t>0?r/t:0;console.log("Before adding to list - Item:",s.item_name),console.log("Quantity:",t,"Total:",r),console.log("Calculated per_item_cost:",a),console.log("Current per_item_cost:",s.per_item_cost||0),Math.abs(a-(s.per_item_cost||0))>.001&&(console.log("Updating per_item_cost from",s.per_item_cost||0,"to",a),u(o=>({...o,per_item_cost:a}))),$!==null?(q(o=>o.map(c=>c.id===$?{...s,id:$}:c)),V(null)):q(o=>[...o,{...s,id:Date.now()}]),u({item_id:0,item_name:"",item_code:"",quantity:1,rate:0,amount:0,gst_percentage:0,gst_amount:0,transport_charge:0,other_charge:0,total:0,per_item_cost:0}),S(""),v.current&&v.current.focus()},he=t=>{if(t){const r=l.find(a=>a.id===t);r&&(u(r),V(t),r.item_code&&S(r.item_code),v.current&&v.current.focus())}},xe=t=>{t&&(q(r=>r.filter(a=>a.id!==t)),$===t&&(V(null),u({item_id:0,item_name:"",item_code:"",quantity:1,rate:0,amount:0,gst_percentage:0,gst_amount:0,transport_charge:0,other_charge:0,total:0,per_item_cost:0}),S("")))},fe=async()=>{if(!F){m("Please select a vendor","error");return}if(l.length===0){m("Please add at least one item","error");return}if(!N){T(!0);try{const t={invoice_number:L,invoice_date:k,vendor_name:F,subtotal:z,total_gst:Q,grand_total:D};let r;if(b&&_){await p.put(`${C}/${_}`,t),r=parseInt(_);const a=await p.get(`${j}?purchase_id=${r}`);for(const o of a.data)await p.delete(`${j}/${o.id}`)}else r=(await p.post(C,t)).data.id;for(const a of l){const o={purchase_id:r,item_id:a.item_id,item_code:a.item_code||"",item_name:a.item_name,quantity:a.quantity,rate:a.rate,amount:a.amount,gst_percentage:a.gst_percentage,gst_amount:a.gst_amount,transport_charge:a.transport_charge||0,other_charge:a.other_charge||0};await p.post(j,o)}m(b?"Purchase updated successfully!":"Purchase saved successfully!","success"),setTimeout(()=>{I("/lists/purchase-list")},500)}catch(t){console.error("Error saving purchase:",t),m(b?"Failed to update purchase":"Failed to save purchase","error")}finally{T(!1)}}},be=async()=>{if(!F){m("Please select a vendor","error");return}if(l.length===0){m("Please add at least one item","error");return}if(!N){T(!0);try{const t={invoice_number:L,invoice_date:k,vendor_name:F,subtotal:z,total_gst:Q,grand_total:D};let r,a={...t};if(b&&_){await p.put(`${C}/${_}`,t),r=parseInt(_),a.id=r;const i=await p.get(`${j}?purchase_id=${r}`);for(const y of i.data)await p.delete(`${j}/${y.id}`)}else r=(await p.post(C,t)).data.id,a.id=r;for(const i of l){const y={purchase_id:r,item_id:i.item_id,item_code:i.item_code||"",item_name:i.item_name,quantity:i.quantity,rate:i.rate,amount:i.amount,gst_percentage:i.gst_percentage,gst_amount:i.gst_amount,transport_charge:i.transport_charge||0,other_charge:i.other_charge||0};await p.post(j,y)}m(b?"Purchase updated successfully!":"Purchase saved successfully!","success");let o=0;const c=l.reduce((i,y)=>i+y.quantity,0);c>0&&(o=D/c);const n=l.reduce((i,y)=>i+(y.transport_charge||0),0),x=l.reduce((i,y)=>i+(y.other_charge||0),0),g={...a,purchase_date:k,items:l},f=window.open("","_blank");f?(f.document.write("<html><head><title>Purchase Invoice</title>"),f.document.write("<style>"),f.document.write(`
          /* Print styles for Purchase Invoice */
          @page {
            size: A4;
            margin: 0.5cm;
          }
          
          body, html {
            margin: 0;
            padding: 0;
            background: white;
            font-size: 12pt;
            color: black;
            font-family: Arial, sans-serif;
          }

          /* Invoice container */
          .print-invoice {
            width: 100%;
            max-width: 100%;
            padding: 20px;
            box-sizing: border-box;
          }

          /* Invoice header */
          .print-header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
          }

          /* Company name */
          .company-name {
            font-size: 24pt;
            font-weight: bold;
            margin-bottom: 5px;
          }

          /* Invoice info */
          .invoice-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #000;
          }

          /* Table styles */
          .print-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
          }

          .print-table th, .print-table td {
            border: 1px solid #000;
            padding: 8px;
          }

          .print-table th {
            background-color: #f2f2f2;
            text-align: left;
            font-weight: bold;
          }

          /* Total row */
          .total-row {
            font-weight: bold;
          }

          /* Signature section */
          .signature-section {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
          }

          .signature-box {
            border-top: 1px solid #000;
            width: 200px;
            padding-top: 5px;
            text-align: center;
          }

          /* Hide page elements when printing */
          @media print {
            body {
              margin: 0;
              padding: 0;
            }
          }
        `),f.document.write("</style></head><body>"),f.document.write(`
          <div class="print-invoice">
            <div class="print-header">
              <div class="company-name">KATHA SALES</div>
              <div>Purchase Invoice</div>
            </div>
            
            <div class="invoice-info">
              <div>
                <div><strong>Invoice Number:</strong> ${g.invoice_number}</div>
                <div><strong>Date:</strong> ${new Date(g.purchase_date).toLocaleDateString()}</div>
              </div>
              <div>
                <div><strong>Vendor:</strong> ${g.vendor_name}</div>
              </div>
            </div>
            
            <table class="print-table">
              <thead>
                <tr>
                  <th>Sr. No.</th>
                  <th>Item Code</th>
                  <th>Item Name</th>
                  <th>Qty</th>
                  <th>Rate</th>
                  <th>Amount</th>
                  <th>GST %</th>
                  <th>GST Amount</th>
                  <th>Total</th>
                </tr>
              </thead>
              <tbody>
                ${g.items.map((i,y)=>`
                  <tr>
                    <td>${y+1}</td>
                    <td>${i.item_code||""}</td>
                    <td>${i.item_name}</td>
                    <td>${i.quantity}</td>
                    <td>${(i.rate||0).toFixed(2)}</td>
                    <td>${(i.amount||0).toFixed(2)}</td>
                    <td>${i.gst_percentage.toFixed(2)}</td>
                    <td>${(i.gst_amount||0).toFixed(2)}</td>
                    <td>${(i.total||0).toFixed(2)}</td>
                  </tr>
                `).join("")}
              </tbody>
              <tfoot>
                <tr class="total-row">
                  <td colspan="3" style="text-align: right;"><strong>Subtotal:</strong></td>
                  <td style="text-align: center;"><strong>${c}</strong></td>
                  <td></td>
                  <td style="text-align: right;"><strong>${g.subtotal.toFixed(2)}</strong></td>
                  <td></td>
                  <td style="text-align: right;"><strong>${g.total_gst.toFixed(2)}</strong></td>
                  <td style="text-align: right;"><strong>${g.grand_total.toFixed(2)}</strong></td>
                </tr>
                <tr>
                  <td colspan="3" style="text-align: right;"><strong>Transport & Other:</strong></td>
                  <td colspan="5"></td>
                  <td style="text-align: right;">
                    <strong>Transport: ${n.toFixed(2)}</strong><br>
                    <strong>Other: ${x.toFixed(2)}</strong>
                  </td>
                </tr>
                <tr class="total-row">
                  <td colspan="8" style="text-align: right;"><strong>Grand Total:</strong></td>
                  <td style="text-align: right;"><strong>${g.grand_total.toFixed(2)}</strong></td>
                </tr>
              </tfoot>
            </table>
            
            <div class="signature-section">
              <div class="signature-box">Authorized Signature</div>
              <div class="signature-box">Received By</div>
            </div>
          </div>
        `),f.document.write("</body></html>"),f.document.close(),setTimeout(()=>{f.print(),setTimeout(()=>{I("/lists/purchase-list")},500)},500)):(m("Could not open print window. Please check if pop-up is blocked.","error"),setTimeout(()=>{I("/lists/purchase-list")},500))}catch(t){console.error("Error saving and printing purchase:",t),m(b?"Failed to update and print purchase":"Failed to save and print purchase","error")}finally{T(!1)}}};return ee?e.jsxs("div",{className:"flex items-center justify-center h-64",children:[e.jsx("div",{className:"animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"}),e.jsx("p",{className:"ml-3 text-gray-600",children:"Loading..."})]}):e.jsxs("div",{ref:Z,className:`bg-white rounded-lg shadow-md ${A?"fullscreen-form":""}`,children:[e.jsxs("div",{className:"bg-primary text-white px-6 py-4 rounded-t-lg flex justify-between items-center",children:[e.jsx("h2",{className:"text-xl font-semibold",children:b?"Edit Purchase Invoice":"New Purchase Invoice"}),e.jsx("div",{className:"flex items-center space-x-2",children:e.jsx("button",{onClick:ie,className:"bg-white/20 hover:bg-white/30 text-white p-1.5 rounded-md transition-colors",title:A?"Exit Fullscreen":"Enter Fullscreen",children:A?e.jsx(we,{className:"h-5 w-5"}):e.jsx(je,{className:"h-5 w-5"})})})]}),e.jsxs("div",{className:"p-6",children:[e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-6 mb-6",children:[e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Invoice No."}),e.jsx("input",{type:"text",value:L,onChange:t=>P(t.target.value),className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Invoice Date"}),e.jsx("input",{type:"date",value:k,onChange:t=>U(t.target.value),className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Vendor Name"}),e.jsxs("select",{value:F,onChange:t=>M(t.target.value),className:"form-select w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50",children:[e.jsx("option",{value:"",children:"-- Select Vendor --"}),oe.map((t,r)=>e.jsx("option",{value:t,children:t},r))]})]})]}),e.jsxs("div",{className:"bg-gray-50 p-4 rounded-lg mb-6",children:[e.jsx("h3",{className:"text-lg font-medium text-gray-700 mb-4",children:"Item Details"}),e.jsxs("div",{className:"grid grid-cols-12 gap-2 mb-4",children:[e.jsxs("div",{className:"col-span-2",children:[e.jsx("label",{htmlFor:"barcode",className:"block text-sm font-medium text-gray-700 mb-1",children:"Item Code"}),e.jsxs("div",{className:"flex",children:[e.jsx("input",{id:"barcode",type:"text",ref:v,className:"p-2 border rounded-l-md w-full",value:R,onChange:me,onKeyDown:ue,placeholder:"Enter code"}),e.jsx("button",{type:"button",onClick:()=>{window.open("http://localhost:5173/forms/item?returnTo=purchase","_blank");const t=r=>{if(r.data&&r.data.newItemCode){const a=r.data.newItemCode;S(a),(async()=>{try{const c=await p.get("http://168.231.122.33:4000/api/item-exact",{params:{code:a.trim()}});c.data&&c.data.item&&(O(c.data.item),v.current&&v.current.focus())}catch(c){console.error("Error fetching new item:",c),m("Error fetching the newly added item","error")}})(),window.removeEventListener("message",t)}};window.addEventListener("message",t)},className:"bg-green-600 text-white px-3 rounded-r-md hover:bg-green-700 flex items-center justify-center",title:"Add New Item",children:e.jsx(X,{className:"h-5 w-5"})})]}),R&&!s.item_id&&e.jsx("p",{className:"text-xs text-red-500 mt-1",children:"Item not found. Try adding it."})]}),e.jsxs("div",{className:"col-span-4",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Item Name"}),e.jsx("input",{type:"text",value:s.item_name,readOnly:!0,className:"form-input w-full rounded-md border-gray-300 bg-gray-100 shadow-sm p-2"})]}),e.jsxs("div",{className:"col-span-2",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Qty"}),e.jsx("input",{type:"number",min:"1",value:s.quantity,onChange:t=>{const r=parseInt(t.target.value)||0;if(G)u({...s,quantity:r});else{const a=r*s.rate;w(a.toFixed(2)),u({...s,quantity:r,amount:a})}},className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 p-2"})]}),e.jsxs("div",{className:"col-span-2",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Rate"}),e.jsx("input",{type:"number",min:"0",step:"0.01",value:s.rate,onChange:t=>{const r=parseFloat(t.target.value)||0;if(G)u({...s,rate:r});else{const a=s.quantity*r;w(a.toFixed(2)),u({...s,rate:r,amount:a})}},className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 p-2"})]}),e.jsxs("div",{className:"col-span-2",children:[e.jsxs("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:["Amount",e.jsx("button",{type:"button",onClick:pe,className:"ml-2 px-1 py-0.5 text-xs bg-blue-100 text-blue-700 rounded",title:"Set to 9622.80",children:"Set 9622.80"})]}),e.jsx("input",{type:"text",value:ne,onFocus:()=>{H(!0),console.log("Amount field focused, disabling auto-calculation")},onChange:t=>{const r=t.target.value;console.log("Setting amount string to:",r),w(r)},onBlur:t=>{const r=t.target.value;console.log("Amount field blurred with value:",r);let a=0;try{r&&r.trim()!==""&&(a=parseFloat(r),isNaN(a)&&(a=0))}catch(o){console.error("Error parsing amount:",o),a=0}console.log("Parsed numeric amount:",a),w(a.toFixed(2)),W(a),H(!1)},className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 p-2"})]})]}),e.jsxs("div",{className:"grid grid-cols-12 gap-2 mb-4",children:[e.jsxs("div",{className:"col-span-2",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"GST %"}),e.jsx("input",{type:"number",min:"0",max:"28",value:s.gst_percentage,onChange:t=>{const r=parseFloat(t.target.value)||0;u({...s,gst_percentage:r})},className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 p-2"})]}),e.jsxs("div",{className:"col-span-2",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"GST Amt"}),e.jsx("input",{type:"number",readOnly:!0,value:s.gst_amount,className:"form-input w-full rounded-md border-gray-300 bg-gray-100 shadow-sm p-2"})]}),e.jsxs("div",{className:"col-span-2",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Transport"}),e.jsx("input",{type:"number",min:"0",step:"0.01",value:s.transport_charge,onChange:t=>{const r=parseFloat(t.target.value)||0;u({...s,transport_charge:r})},className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 p-2"})]}),e.jsxs("div",{className:"col-span-2",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Other"}),e.jsx("input",{type:"number",min:"0",step:"0.01",value:s.other_charge,onChange:t=>{const r=parseFloat(t.target.value)||0;u({...s,other_charge:r})},className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 p-2"})]}),e.jsxs("div",{className:"col-span-2",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Total"}),e.jsx("input",{type:"text",readOnly:!0,value:h(s.total||0),className:"form-input w-full rounded-md border-gray-300 bg-gray-100 shadow-sm p-2"})]}),e.jsxs("div",{className:"col-span-2",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Per Item Cost"}),e.jsx("input",{type:"text",readOnly:!0,value:h(s.per_item_cost||0),className:"form-input w-full rounded-md border-gray-300 bg-gray-100 shadow-sm p-2"})]})]}),e.jsx("div",{className:"bg-gray-100 p-4 mt-6 rounded-lg text-center",children:e.jsxs(B,{id:"add-item-button",onClick:ge,variant:"primary",size:"lg",className:"bg-green-600 hover:bg-green-700 text-white px-8 py-3 text-lg rounded-lg font-bold shadow-md",children:[e.jsx(X,{className:"h-6 w-6 mr-2"}),$?"Update Item":"Add Item"]})})]}),e.jsx("div",{className:"mb-6 overflow-x-auto",children:e.jsxs("table",{className:"w-full border-collapse",children:[e.jsx("thead",{children:e.jsxs("tr",{className:"bg-gray-100",children:[e.jsx("th",{className:"py-2 px-4 text-left border",children:"Item Code"}),e.jsx("th",{className:"py-2 px-4 text-left border",children:"Item Name"}),e.jsx("th",{className:"py-2 px-4 text-right border",children:"Qty"}),e.jsx("th",{className:"py-2 px-4 text-right border",children:"Rate"}),e.jsx("th",{className:"py-2 px-4 text-right border",children:"Amount"}),e.jsx("th",{className:"py-2 px-4 text-right border",children:"GST %"}),e.jsx("th",{className:"py-2 px-4 text-right border",children:"GST Amt"}),e.jsx("th",{className:"py-2 px-4 text-right border",children:"Transport"}),e.jsx("th",{className:"py-2 px-4 text-right border",children:"Other"}),e.jsx("th",{className:"py-2 px-4 text-right border",children:"Total"}),e.jsx("th",{className:"py-2 px-4 text-center border",children:"Actions"})]})}),e.jsx("tbody",{children:l.length===0?e.jsx("tr",{children:e.jsx("td",{colSpan:11,className:"py-4 text-center text-gray-500 border",children:"No items added yet. Use the form above to add items."})}):l.map(t=>e.jsxs("tr",{className:"hover:bg-gray-50",children:[e.jsx("td",{className:"py-2 px-4 border",children:t.item_code}),e.jsx("td",{className:"py-2 px-4 border",children:t.item_name}),e.jsx("td",{className:"py-2 px-4 text-right border",children:t.quantity}),e.jsx("td",{className:"py-2 px-4 text-right border",children:h(t.rate)}),e.jsx("td",{className:"py-2 px-4 text-right border",children:h(t.amount)}),e.jsx("td",{className:"py-2 px-4 text-right border",children:t.gst_percentage.toFixed(2)}),e.jsx("td",{className:"py-2 px-4 text-right border",children:h(t.gst_amount)}),e.jsx("td",{className:"py-2 px-4 text-right border",children:h(t.transport_charge)}),e.jsx("td",{className:"py-2 px-4 text-right border",children:h(t.other_charge)}),e.jsx("td",{className:"py-2 px-4 text-right border",children:h(t.total)}),e.jsxs("td",{className:"py-2 px-4 text-center border",children:[e.jsx("button",{onClick:()=>he(t.id),className:"text-blue-600 hover:text-blue-800 mr-2",children:"Edit"}),e.jsx("button",{onClick:()=>xe(t.id),className:"text-red-600 hover:text-red-800",children:"Delete"})]})]},t.id))}),e.jsx("tfoot",{children:e.jsxs("tr",{className:"bg-gray-100 font-medium",children:[e.jsx("td",{colSpan:2,className:"text-right pr-4 py-2 border",children:"Total:"}),e.jsx("td",{className:"text-right pr-4 py-2 border",children:l.reduce((t,r)=>t+r.quantity,0)}),e.jsx("td",{className:"text-right pr-4 py-2 border"}),e.jsx("td",{className:"text-right pr-4 py-2 border",children:h(z)}),e.jsx("td",{className:"text-right pr-4 py-2 border"}),e.jsx("td",{className:"text-right pr-4 py-2 border",children:h(Q)}),e.jsx("td",{className:"text-right pr-4 py-2 border",children:h(l.reduce((t,r)=>t+(r.transport_charge||0),0))}),e.jsx("td",{className:"text-right pr-4 py-2 border",children:h(l.reduce((t,r)=>t+(r.other_charge||0),0))}),e.jsx("td",{className:"text-right pr-4 py-2 border",children:h(D)}),e.jsx("td",{className:"border"})]})})]})}),e.jsxs("div",{className:"flex justify-end space-x-4",children:[e.jsx(B,{onClick:()=>I("/lists/purchase-list"),className:"bg-gray-200 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-300 transition-colors",children:"Cancel"}),e.jsx(B,{onClick:fe,disabled:N,className:`bg-green-600 text-white px-6 py-2 rounded-md transition-colors ${N?"opacity-70 cursor-not-allowed":"hover:bg-green-700 cursor-pointer"}`,children:N?"Saving...":b?"Update":"Save"}),e.jsx(B,{onClick:be,disabled:N,className:`bg-blue-600 text-white px-6 py-2 rounded-md transition-colors ${N?"opacity-70 cursor-not-allowed":"hover:bg-blue-700 cursor-pointer"}`,children:N?"Processing...":"Save & Print"})]})]}),e.jsx("div",{ref:Y,className:"hidden"})]})};export{ke as default};
