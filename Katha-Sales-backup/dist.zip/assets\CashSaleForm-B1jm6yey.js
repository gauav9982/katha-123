import{u as pe,c as he,a as ge,r as n,d as xe,b as d,j as e}from"./index-Cn6DFgxh.js";import{B as D}from"./Button-DbIH54Da.js";import{F as fe,a as be,h as ye}from"./itemLookup-B-tAzo2_.js";import{A as M}from"./config-DOZbGk3J.js";import{F as ve}from"./PlusIcon-Cy10Ib0F.js";const we=M.ITEMS,j=M.CASHSALES,y=M.CASHSALE_ITEMS,Ee=()=>{const v=pe(),{id:p}=he(),{showAlert:c}=ge(),g=n.useRef(null),K=n.useRef(null),W=n.useRef(null),[C,G]=n.useState(!1),[V,E]=n.useState(!1),[m,Ne]=n.useState(!!p),[x,$]=n.useState(!1),[R,k]=n.useState(""),[q,B]=n.useState(new Date().toISOString().split("T")[0]),[_,H]=n.useState(""),[w,O]=n.useState("MRP Sales"),[J,X]=n.useState([]),[u,P]=n.useState([]),[S,N]=n.useState(""),[I,T]=n.useState(null),[i,h]=n.useState({item_id:0,item_name:"",item_code:"",quantity:1,rate:0,amount:0}),[f,A]=n.useState({name:"",lastCost:0,lastPurchaseDate:""}),[Q,Y]=n.useState(0),[L,Z]=n.useState(0),ee=["MRP Sales","5% Sales","10% Sales","20% Sales","30% Sales","40% Sales"],te=["Customer 1","Customer 2","Customer 3","Walk-in Customer","Regular Customer"],se=()=>{G(!C)};n.useEffect(()=>{re(),(async()=>{m||await ae()})(),m&&p&&oe(p)},[m,p]);const U=xe();n.useEffect(()=>{const s=new URLSearchParams(U.search).get("newItemCode");s&&(N(s),(async()=>{try{const o=await d.get("http://168.231.122.33:4000/api/item-exact",{params:{code:s.trim()}});o.data&&o.data.item&&(F(o.data.item),(o.data.lastCost||o.data.lastPurchaseDate)&&A({name:o.data.item.item_name,lastCost:o.data.lastCost||0,lastPurchaseDate:o.data.lastPurchaseDate||"No purchase"}),g.current&&g.current.focus())}catch(o){console.error("Error fetching new item:",o),c("Error fetching the newly added item","error")}})(),v("/forms/cashsale-form",{replace:!0}))},[U]);const ae=async()=>{if(!m)try{const a=((await d.get(j)).data||[]).map(r=>r.invoice_number).filter(r=>/^\d+$/.test(r)).map(r=>parseInt(r,10)),l=(a.length>0?Math.max(...a):0)+1;k(l.toString())}catch(t){console.error("Error generating invoice number:",t),k("1")}},re=async()=>{E(!0);try{const s=(await d.get(we)).data.map(a=>(a.item_code!==void 0&&a.item_code!==null&&(a.item_code=a.item_code.toString().trim()),a));X(s),console.log(`Loaded ${s.length} items from backend API`)}catch(t){console.error("Error loading items:",t),c("Failed to load items from server","error")}finally{E(!1)}},oe=async t=>{E(!0);try{const a=(await d.get(`${j}/${t}`)).data;k(a.invoice_number),B(a.invoice_date),H(a.customer_name),O(a.sales_type);const l=(await d.get(`${y}?sale_id=${t}`)).data.map(r=>({id:r.id,item_id:r.item_id,item_name:r.item_name,item_code:r.item_code||"",quantity:r.quantity,rate:r.rate,amount:r.amount}));P(l)}catch(s){console.error("Error fetching cash sale for editing:",s),c("Failed to load cash sale data","error"),v("/lists/cashsale-list")}finally{E(!1)}};n.useEffect(()=>{const t=u.reduce((s,a)=>s+a.amount,0);Y(t),Z(t)},[u]);const z=t=>Number.isInteger(t)?t.toString():t.toFixed(2).replace(/\.00$/,"").replace(/\.(\d)0$/,".$1"),ne=async t=>{const s=t.target.value.trim();N(s),s===""&&(h({item_id:0,item_name:"",item_code:"",quantity:1,rate:0,amount:0}),A({name:"",lastCost:0,lastPurchaseDate:""}))},ie=t=>{ye(t,S,s=>{var a;console.log("Exact match found on Tab/Enter:",s.item.item_name),A({name:s.item.item_name,lastCost:s.lastCost||0,lastPurchaseDate:s.lastPurchaseDate||"No purchase"}),F(s.item),t.key==="Enter"&&((a=document.getElementById("add-item-button"))==null||a.click())},s=>{console.error("Error in exact item lookup:",s),c("Item not found with this exact code","error"),h({item_id:0,item_name:"",item_code:S,quantity:1,rate:0,amount:0}),A({name:"",lastCost:0,lastPurchaseDate:""})})},F=t=>{let s=0;if(w==="MRP Sales")s=t.mrp||0;else{const o=w.match(/(\d+)% Sales/);if(o&&o[1]){const l=parseInt(o[1],10);if(f.lastCost&&f.lastCost>0)s=f.lastCost+f.lastCost*l/100;else{const r=t.opening_cost||0;s=r+r*l/100}}else s=t.mrp||0}const a=s;h({item_id:t.id,item_name:t.item_name,item_code:t.item_code||"",quantity:1,rate:s,amount:a})};n.useEffect(()=>{if(i.item_id){const t=i.quantity,s=i.rate,a=t*s;h(o=>({...o,amount:a}))}},[i.quantity,i.rate]),n.useEffect(()=>{if(i.item_id){const t=J.find(s=>s.id===i.item_id);t&&F(t)}},[w]);const le=()=>{if(i.item_id===0){c("Please select an item","error");return}if(i.quantity<=0){c("Quantity must be greater than zero","error");return}if(i.rate<=0){c("Rate must be greater than zero","error");return}I!==null?(P(t=>t.map(s=>s.id===I?{...i,id:I}:s)),T(null)):P(t=>[...t,{...i,id:Date.now()}]),h({item_id:0,item_name:"",item_code:"",quantity:1,rate:0,amount:0}),N(""),g.current&&g.current.focus()},ce=t=>{if(t){const s=u.find(a=>a.id===t);s&&(h(s),T(t),s.item_code&&N(s.item_code),g.current&&g.current.focus())}},de=t=>{t&&(P(s=>s.filter(a=>a.id!==t)),I===t&&(T(null),h({item_id:0,item_name:"",item_code:"",quantity:1,rate:0,amount:0}),N("")))},me=async()=>{if(!_){c("Please select a customer","error");return}if(u.length===0){c("Please add at least one item","error");return}if(!x){$(!0);try{const t={invoice_number:R,invoice_date:q,customer_name:_,sales_type:w,subtotal:Q,grand_total:L};let s;if(m&&p){await d.put(`${j}/${p}`,t),s=parseInt(p);const a=await d.get(`${y}?sale_id=${s}`);for(const o of a.data)await d.delete(`${y}/${o.id}`)}else s=(await d.post(j,t)).data.id;for(const a of u){const o={sale_id:s,item_id:a.item_id,item_name:a.item_name,item_code:a.item_code||"",quantity:a.quantity,rate:a.rate,amount:a.amount};await d.post(y,o)}c(m?"Cash Sale updated successfully!":"Cash Sale saved successfully!","success"),setTimeout(()=>{v("/lists/cashsale-list")},500)}catch(t){console.error("Error saving cash sale:",t),c(m?"Failed to update cash sale":"Failed to save cash sale","error")}finally{$(!1)}}},ue=async()=>{if(!_){c("Please select a customer","error");return}if(u.length===0){c("Please add at least one item","error");return}if(!x){$(!0);try{const t={invoice_number:R,invoice_date:q,customer_name:_,sales_type:w,subtotal:Q,grand_total:L};let s,a={...t};if(m&&p){await d.put(`${j}/${p}`,t),s=parseInt(p),a.id=s;const r=await d.get(`${y}?sale_id=${s}`);for(const b of r.data)await d.delete(`${y}/${b.id}`)}else s=(await d.post(j,t)).data.id,a.id=s;for(const r of u){const b={sale_id:s,item_id:r.item_id,item_name:r.item_name,item_code:r.item_code||"",quantity:r.quantity,rate:r.rate,amount:r.amount};await d.post(y,b)}c(m?"Cash Sale updated successfully!":"Cash Sale saved successfully!","success");const o={...a,items:u},l=window.open("","_blank");l?(l.document.write("<html><head><title>Cash Sale Invoice</title>"),l.document.write("<style>"),l.document.write(`
          /* Print styles for Cash Sale Invoice */
          @page {
            size: A4;
            margin: 0.5cm;
          }
          
          body, html {
            margin: 0;
            padding: 0;
            background: white;
            font-size: 12pt;
            color: black;
            font-family: Arial, sans-serif;
          }

          /* Invoice container */
          .print-invoice {
            width: 100%;
            max-width: 100%;
            padding: 20px;
            box-sizing: border-box;
          }

          /* Invoice header */
          .print-header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
          }

          /* Company name */
          .company-name {
            font-size: 24pt;
            font-weight: bold;
            margin-bottom: 5px;
          }

          /* Invoice info */
          .invoice-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #000;
          }

          /* Table styles */
          .print-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
          }

          .print-table th, .print-table td {
            border: 1px solid #000;
            padding: 8px;
          }

          .print-table th {
            background-color: #f2f2f2;
            text-align: left;
            font-weight: bold;
          }

          /* Total row */
          .total-row {
            font-weight: bold;
          }

          /* Signature section */
          .signature-section {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
          }

          .signature-box {
            border-top: 1px solid #000;
            width: 200px;
            padding-top: 5px;
            text-align: center;
          }

          /* Fullscreen form */
          .fullscreen-form {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            z-index: 9999;
            overflow: auto;
          }

          /* Hide page elements when printing */
          @media print {
            body {
              margin: 0;
              padding: 0;
            }
            
            .no-print {
              display: none;
            }
          }
          
          /* Print controls */
          .print-controls {
            padding: 15px;
            background-color: #f0f4f8;
            border-bottom: 1px solid #ccc;
            text-align: center;
          }
          
          .print-button {
            background-color: #4CAF50;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            margin-right: 10px;
          }
          
          .print-button:hover {
            background-color: #45a049;
          }
          
          .close-button {
            background-color: #f44336;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
          }
          
          .close-button:hover {
            background-color: #d32f2f;
          }
        `),l.document.write("</style></head><body>"),l.document.write(`
          <div class="print-controls no-print">
            <button class="print-button" onclick="window.print()">Print</button>
            <button class="close-button" onclick="window.close()">Close</button>
          </div>
        `),l.document.write(`
          <div class="print-invoice">
            <div class="print-header">
              <div class="company-name">KATHA SALES</div>
              <div>Cash Sale Invoice</div>
            </div>
            
            <div class="invoice-info">
              <div>
                <div><strong>Invoice Number:</strong> ${o.invoice_number}</div>
                <div><strong>Date:</strong> ${new Date(o.invoice_date).toLocaleDateString()}</div>
                <div><strong>Sales Type:</strong> ${o.sales_type}</div>
              </div>
              <div>
                <div><strong>Customer:</strong> ${o.customer_name}</div>
              </div>
            </div>
            
            <table class="print-table">
              <thead>
                <tr>
                  <th>Sr. No.</th>
                  <th>Item Code</th>
                  <th>Item Name</th>
                  <th>Qty</th>
                  <th>Rate</th>
                  <th>Amount</th>
                </tr>
              </thead>
              <tbody>
                ${o.items.map((r,b)=>`
                  <tr>
                    <td>${b+1}</td>
                    <td>${r.item_code||""}</td>
                    <td>${r.item_name}</td>
                    <td>${r.quantity}</td>
                    <td>${(r.rate||0).toFixed(2)}</td>
                    <td>${(r.amount||0).toFixed(2)}</td>
                  </tr>
                `).join("")}
              </tbody>
              <tfoot>
                <tr class="total-row">
                  <td colspan="3" style="text-align: right;"><strong>Total:</strong></td>
                  <td style="text-align: center;"><strong>${o.items.reduce((r,b)=>r+b.quantity,0)}</strong></td>
                  <td></td>
                  <td style="text-align: right;"><strong>${o.grand_total.toFixed(2)}</strong></td>
                </tr>
              </tfoot>
            </table>
            
            <div class="signature-section">
              <div class="signature-box">Authorized Signature</div>
              <div class="signature-box">Received By</div>
            </div>
          </div>
        `),l.document.write("</body></html>"),l.document.close(),l.onafterprint=()=>{setTimeout(()=>{v("/lists/cashsale-list")},500)}):(c("Could not open print window. Please check if pop-up is blocked.","error"),setTimeout(()=>{v("/lists/cashsale-list")},500))}catch(t){console.error("Error saving and printing cash sale:",t),c(m?"Failed to update and print cash sale":"Failed to save and print cash sale","error")}finally{$(!1)}}};return V?e.jsxs("div",{className:"flex items-center justify-center h-64",children:[e.jsx("div",{className:"animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"}),e.jsx("p",{className:"ml-3 text-gray-600",children:"Loading..."})]}):e.jsxs("div",{ref:W,className:`bg-white rounded-lg shadow-md ${C?"fullscreen-form":""}`,children:[e.jsxs("div",{className:"bg-primary text-white px-6 py-4 rounded-t-lg flex justify-between items-center",children:[e.jsx("h2",{className:"text-xl font-semibold",children:m?"Edit Cash Sale Invoice":"New Cash Sale Invoice"}),e.jsx("div",{className:"flex items-center space-x-2",children:e.jsx("button",{onClick:se,className:"bg-white/20 hover:bg-white/30 text-white p-1.5 rounded-md transition-colors",title:C?"Exit Fullscreen":"Enter Fullscreen",children:C?e.jsx(fe,{className:"h-5 w-5"}):e.jsx(be,{className:"h-5 w-5"})})})]}),e.jsxs("div",{className:"p-6",children:[e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-4 gap-6 mb-6",children:[e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Sales Type"}),e.jsx("select",{value:w,onChange:t=>O(t.target.value),className:"form-select w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50",children:ee.map((t,s)=>e.jsx("option",{value:t,children:t},s))})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Invoice No."}),e.jsx("input",{type:"text",value:R,onChange:t=>k(t.target.value),className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Invoice Date"}),e.jsx("input",{type:"date",value:q,onChange:t=>B(t.target.value),className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Customer Name"}),e.jsxs("select",{value:_,onChange:t=>H(t.target.value),className:"form-select w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50",children:[e.jsx("option",{value:"",children:"-- Select Customer --"}),te.map((t,s)=>e.jsx("option",{value:t,children:t},s))]})]})]}),e.jsxs("div",{className:"bg-gray-50 p-4 rounded-lg mb-6",children:[e.jsx("h3",{className:"text-lg font-medium text-gray-700 mb-4",children:"Item Details"}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-12 gap-3 mb-5",children:[e.jsxs("div",{className:"md:col-span-4 relative",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Item Code"}),e.jsxs("div",{className:"flex",children:[e.jsx("input",{ref:g,type:"text",value:S,onChange:ne,onKeyDown:ie,className:`form-input w-full rounded-l-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 ${i.item_id?"border-green-500":S&&!i.item_id?"border-red-500":""}`,placeholder:"Enter item code or barcode"}),e.jsx("button",{type:"button",onClick:()=>{window.open("http://localhost:5173/forms/item?returnTo=cash","_blank");const t=s=>{if(s.data&&s.data.newItemCode){const a=s.data.newItemCode;N(a),(async()=>{try{const l=await d.get("http://168.231.122.33:4000/api/item-exact",{params:{code:a.trim()}});l.data&&l.data.item&&(F(l.data.item),g.current&&g.current.focus())}catch(l){console.error("Error fetching new item:",l),c("Error fetching the newly added item","error")}})(),window.removeEventListener("message",t)}};window.addEventListener("message",t)},className:"bg-green-600 text-white px-3 rounded-r-md hover:bg-green-700 flex items-center justify-center",title:"Add New Item",children:e.jsx(ve,{className:"h-5 w-5"})})]}),S&&!i.item_id&&e.jsx("p",{className:"text-xs text-red-500 mt-1",children:"Item not found. Try adding it."}),f.name&&e.jsxs("div",{className:"mt-2 p-2 bg-blue-50 rounded-md text-sm",children:[e.jsx("div",{className:"font-semibold text-blue-800",children:"Item Details:"}),e.jsxs("div",{className:"grid grid-cols-3 gap-2 mt-1",children:[e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"Name:"})," ",f.name]}),e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"Per Item Cost:"})," ₹",parseFloat(f.lastCost).toFixed(2)]}),e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"Last Purchase:"})," ",f.lastPurchaseDate]})]})]})]}),e.jsxs("div",{className:"md:col-span-4",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Item Name"}),e.jsx("input",{type:"text",value:i.item_name,readOnly:!0,className:"form-input w-full rounded-md border-gray-300 bg-gray-100 shadow-sm"})]}),e.jsxs("div",{className:"md:col-span-1",style:{maxWidth:"100px"},children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Qty"}),e.jsx("input",{type:"number",min:"1",value:i.quantity,onChange:t=>{const s=parseInt(t.target.value)||0;h({...i,quantity:s})},className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"})]}),e.jsxs("div",{className:"md:col-span-1",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Rate"}),e.jsx("input",{type:"number",min:"0",step:"0.01",value:i.rate,onChange:t=>{const s=parseFloat(t.target.value)||0;h({...i,rate:s})},className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"})]}),e.jsxs("div",{className:"md:col-span-2",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Amount"}),e.jsx("input",{type:"number",step:"0.01",value:i.amount,onChange:t=>{const s=parseFloat(t.target.value)||0,a=i.quantity||1,o=a>0?s/a:0;h({...i,amount:s,rate:o})},className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"})]})]}),e.jsx("div",{className:"flex justify-end",children:e.jsx(D,{id:"add-item-button",onClick:le,className:"bg-primary text-white px-6 py-2 rounded-md hover:bg-primary-dark transition-colors",children:I!==null?"Update Item":"Add Item"})})]}),e.jsx("div",{className:"mb-6 overflow-x-auto",children:e.jsxs("table",{className:"w-full border-collapse",children:[e.jsx("thead",{children:e.jsxs("tr",{className:"bg-gray-100",children:[e.jsx("th",{className:"py-2 px-4 text-left border",children:"Item Code"}),e.jsx("th",{className:"py-2 px-4 text-left border",children:"Item Name"}),e.jsx("th",{className:"py-2 px-4 text-right border",children:"Qty"}),e.jsx("th",{className:"py-2 px-4 text-right border",children:"Rate"}),e.jsx("th",{className:"py-2 px-4 text-right border",children:"Amount"}),e.jsx("th",{className:"py-2 px-4 text-center border",children:"Actions"})]})}),e.jsx("tbody",{children:u.length===0?e.jsx("tr",{children:e.jsx("td",{colSpan:6,className:"py-4 text-center text-gray-500 border",children:"No items added yet. Use the form above to add items."})}):u.map(t=>e.jsxs("tr",{className:"hover:bg-gray-50",children:[e.jsx("td",{className:"py-2 px-4 border",children:t.item_code}),e.jsx("td",{className:"py-2 px-4 border",children:t.item_name}),e.jsx("td",{className:"py-2 px-4 text-right border",children:t.quantity}),e.jsx("td",{className:"py-2 px-4 text-right border",children:z(t.rate)}),e.jsx("td",{className:"py-2 px-4 text-right border",children:z(t.amount)}),e.jsxs("td",{className:"py-2 px-4 text-center border",children:[e.jsx("button",{onClick:()=>ce(t.id),className:"text-blue-600 hover:text-blue-800 mr-2",children:"Edit"}),e.jsx("button",{onClick:()=>de(t.id),className:"text-red-600 hover:text-red-800",children:"Delete"})]})]},t.id))}),e.jsx("tfoot",{children:e.jsxs("tr",{className:"bg-gray-100 font-medium",children:[e.jsx("td",{colSpan:2,className:"text-right pr-4 py-2 border",children:"Total:"}),e.jsx("td",{className:"text-right pr-4 border",children:u.reduce((t,s)=>t+s.quantity,0)}),e.jsx("td",{className:"text-right pr-4 border"}),e.jsx("td",{className:"text-right pr-4 border",children:z(L)}),e.jsx("td",{className:"border"})]})})]})}),e.jsxs("div",{className:"flex justify-end space-x-4",children:[e.jsx(D,{onClick:()=>v("/lists/cashsale-list"),className:"bg-gray-200 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-300 transition-colors",children:"Cancel"}),e.jsx(D,{onClick:me,disabled:x,className:`bg-green-600 text-white px-6 py-2 rounded-md transition-colors ${x?"opacity-70 cursor-not-allowed":"hover:bg-green-700 cursor-pointer"}`,children:x?"Saving...":m?"Update":"Save"}),e.jsx(D,{onClick:ue,disabled:x,className:`bg-blue-600 text-white px-6 py-2 rounded-md transition-colors ${x?"opacity-70 cursor-not-allowed":"hover:bg-blue-700 cursor-pointer"}`,children:x?"Processing...":"Save & Print"})]})]}),e.jsx("div",{ref:K,className:"hidden"})]})};export{Ee as default};
