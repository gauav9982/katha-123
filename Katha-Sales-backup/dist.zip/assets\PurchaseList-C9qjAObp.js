import{r as p,u as D,d as z,a as B,b as c,j as t,L as P}from"./index-Cn6DFgxh.js";import{B as $}from"./Button-DbIH54Da.js";/* empty css                      */const w="http://168.231.122.33:4000/api/purchases",v="http://168.231.122.33:4000/api/purchase-items",K=()=>{const[_,h]=p.useState(!0),[k,I]=p.useState(0),S=D(),g=z(),{showAlert:i,updatedPurchase:d,clearUpdatedPurchase:x,purchases:m,setPurchases:u,updatePurchase:j}=B(),N=p.useCallback(async()=>{try{console.log("Loading purchases from API..."),h(!0);const s=(await c.get(w)).data||[];console.log("Purchases loaded from API:",s),u(s),console.log("Checking store for updated purchase:",d),d&&d.id&&(console.log("Found updated purchase in store:",d),j(d),x(),i("Purchase list updated with latest changes","success"))}catch(e){console.error("Error loading purchases:",e),i("Failed to load purchases from server","error")}finally{h(!1)}},[u,d,j,x,i]);p.useEffect(()=>{N()},[k,N]),p.useEffect(()=>{const e=document.referrer==="";g.pathname==="/lists/purchase-list"&&!e&&g.key!==void 0&&(console.log("Back to purchase list, forcing reload"),I(s=>s+1))},[g]);const A=e=>{localStorage.removeItem("updatedPurchase"),x(),S(`/forms/purchase/${e}`)},F=async e=>{if(window.confirm("Are you sure you want to delete this purchase?"))try{h(!0);const y=(await c.get(`${v}?purchase_id=${e}`)).data||[];for(const l of y)await c.delete(`${v}/${l.id}`);await c.delete(`${w}/${e}`);const f=m.filter(l=>l.id!==e);u(f),i("Purchase deleted successfully","success")}catch(s){console.error("Error deleting purchase:",s),i("Failed to delete purchase","error")}finally{h(!1)}},C=async e=>{try{let s=e;if((!e.items||e.items.length===0)&&e.id){const r=await c.get(`${w}/${e.id}`),b=(await c.get(`${v}?purchase_id=${e.id}`)).data.map(n=>{if(!n.total){const T=n.amount||0,E=n.gst_amount||0,L=n.transport_charge||0,R=n.other_charge||0;n.total=T+E+L+R}return n});s={...r.data,items:b||[]}}let y=0;if(s.items&&s.items.length>0){const r=s.items.reduce((a,b)=>a+b.quantity,0);r>0&&(y=s.grand_total/r)}const f=s.items.reduce((r,a)=>r+(a.transport_charge||0),0),l=s.items.reduce((r,a)=>r+(a.other_charge||0),0),o=window.open("","_blank");o?(o.document.write("<html><head><title>Purchase Invoice</title>"),o.document.write("<style>"),o.document.write(`
          /* Print styles for Purchase Invoice */
          @page {
            size: A4;
            margin: 0.5cm;
          }
          
          body, html {
            margin: 0;
            padding: 0;
            background: white;
            font-size: 12pt;
            color: black;
            font-family: Arial, sans-serif;
          }

          /* Invoice container */
          .print-invoice {
            width: 100%;
            max-width: 100%;
            padding: 20px;
            box-sizing: border-box;
          }

          /* Invoice header */
          .print-header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
          }

          /* Company name */
          .company-name {
            font-size: 24pt;
            font-weight: bold;
            margin-bottom: 5px;
          }

          /* Invoice info */
          .invoice-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #000;
          }

          /* Table styles */
          .print-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
          }

          .print-table th, .print-table td {
            border: 1px solid #000;
            padding: 8px;
          }

          .print-table th {
            background-color: #f2f2f2;
            text-align: left;
            font-weight: bold;
          }

          /* Total row */
          .total-row {
            font-weight: bold;
          }

          /* Signature section */
          .signature-section {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
          }

          .signature-box {
            border-top: 1px solid #000;
            width: 200px;
            padding-top: 5px;
            text-align: center;
          }

          /* Hide page elements when printing */
          @media print {
            body {
              margin: 0;
              padding: 0;
            }
          }
        `),o.document.write("</style></head><body>"),o.document.write(`
          <div class="print-invoice">
            <div class="print-header">
              <div class="company-name">KATHA SALES</div>
              <div>Purchase Invoice</div>
            </div>
            
            <div class="invoice-info">
              <div>
                <div><strong>Invoice Number:</strong> ${s.invoice_number}</div>
                <div><strong>Date:</strong> ${new Date(s.invoice_date||s.purchase_date).toLocaleDateString()}</div>
              </div>
              <div>
                <div><strong>Vendor:</strong> ${s.vendor_name}</div>
              </div>
            </div>
            
            <table class="print-table">
              <thead>
                <tr>
                  <th>Sr. No.</th>
                  <th>Item Code</th>
                  <th>Item Name</th>
                  <th>Qty</th>
                  <th>Rate</th>
                  <th>Amount</th>
                  <th>GST %</th>
                  <th>GST Amount</th>
                  <th>Total</th>
                </tr>
              </thead>
              <tbody>
                ${s.items.map((r,a)=>`
                  <tr>
                    <td>${a+1}</td>
                    <td>${r.item_code||""}</td>
                    <td>${r.item_name}</td>
                    <td>${r.quantity}</td>
                    <td>${(r.rate||0).toFixed(2)}</td>
                    <td>${(r.amount||0).toFixed(2)}</td>
                    <td>${r.gst_percentage}%</td>
                    <td>${(r.gst_amount||0).toFixed(2)}</td>
                    <td>${(r.total||0).toFixed(2)}</td>
                  </tr>
                `).join("")}
              </tbody>
              <tfoot>
                <tr class="total-row">
                  <td colspan="3" style="text-align: right;"><strong>Subtotal:</strong></td>
                  <td style="text-align: center;"><strong>${s.items.reduce((r,a)=>r+a.quantity,0)}</strong></td>
                  <td></td>
                  <td style="text-align: right;"><strong>${s.subtotal.toFixed(2)}</strong></td>
                  <td></td>
                  <td style="text-align: right;"><strong>${s.total_gst.toFixed(2)}</strong></td>
                  <td style="text-align: right;"><strong>${s.grand_total.toFixed(2)}</strong></td>
                </tr>
                <tr>
                  <td colspan="3" style="text-align: right;"><strong>Transport & Other:</strong></td>
                  <td colspan="5"></td>
                  <td style="text-align: right;">
                    <strong>Transport: ${f.toFixed(2)}</strong><br>
                    <strong>Other: ${l.toFixed(2)}</strong>
                  </td>
                </tr>
                <tr class="total-row">
                  <td colspan="8" style="text-align: right;"><strong>Grand Total:</strong></td>
                  <td style="text-align: right;"><strong>${s.grand_total.toFixed(2)}</strong></td>
                </tr>
              </tfoot>
            </table>
            
            <div class="signature-section">
              <div class="signature-box">Authorized Signature</div>
              <div class="signature-box">Received By</div>
            </div>
          </div>
        `),o.document.write("</body></html>"),o.document.close(),setTimeout(()=>{o.print()},500)):i("Could not open print window. Please check if pop-up is blocked.","error")}catch(s){console.error("Error printing purchase:",s),i("Failed to print purchase","error")}};return _?t.jsxs("div",{className:"flex items-center justify-center h-64",children:[t.jsx("div",{className:"animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"}),t.jsx("p",{className:"ml-3 text-gray-600",children:"Loading purchases..."})]}):t.jsxs("div",{className:"bg-white rounded-lg shadow-md",children:[t.jsxs("div",{className:"flex justify-between items-center bg-primary text-white px-6 py-4 rounded-t-lg",children:[t.jsx("h2",{className:"text-xl font-semibold",children:"Purchase List"}),t.jsx("div",{children:t.jsx(P,{to:"/forms/purchase",children:t.jsx($,{className:"bg-white text-primary hover:bg-gray-100",children:"Create New Purchase"})})})]}),t.jsx("div",{className:"p-6",children:m.length===0?t.jsxs("div",{className:"text-center py-12 bg-gray-50 rounded-lg",children:[t.jsx("h3",{className:"text-lg font-medium text-gray-500 mb-2",children:"No Purchases Found"}),t.jsx("p",{className:"text-gray-400 mb-4",children:"Create your first purchase to get started."}),t.jsx(P,{to:"/forms/purchase",children:t.jsx($,{className:"bg-primary text-white hover:bg-primary-dark",children:"Create Purchase"})})]}):t.jsx("div",{className:"overflow-x-auto",children:t.jsxs("table",{className:"min-w-full divide-y divide-gray-200",children:[t.jsx("thead",{className:"bg-gray-50",children:t.jsxs("tr",{children:[t.jsx("th",{scope:"col",className:"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Invoice #"}),t.jsx("th",{scope:"col",className:"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Date"}),t.jsx("th",{scope:"col",className:"px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Vendor"}),t.jsx("th",{scope:"col",className:"px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Subtotal"}),t.jsx("th",{scope:"col",className:"px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider",children:"GST"}),t.jsx("th",{scope:"col",className:"px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Total"}),t.jsx("th",{scope:"col",className:"px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Actions"})]})}),t.jsx("tbody",{className:"bg-white divide-y divide-gray-200",children:m.map(e=>t.jsxs("tr",{className:"hover:bg-gray-50",children:[t.jsx("td",{className:"px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900",children:e.invoice_number}),t.jsx("td",{className:"px-6 py-4 whitespace-nowrap text-sm text-gray-500",children:e.invoice_date?new Date(e.invoice_date).toLocaleDateString():"No date"}),t.jsx("td",{className:"px-6 py-4 whitespace-nowrap text-sm text-gray-500",children:e.vendor_name}),t.jsx("td",{className:"px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right",children:e.subtotal.toFixed(2)}),t.jsx("td",{className:"px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right",children:e.total_gst.toFixed(2)}),t.jsx("td",{className:"px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-medium text-right",children:e.grand_total.toFixed(2)}),t.jsxs("td",{className:"px-6 py-4 whitespace-nowrap text-right text-sm font-medium",children:[t.jsx("button",{onClick:()=>C(e),className:"text-gray-600 hover:text-gray-900 mr-3",title:"Print",children:"🖨️"}),t.jsx("button",{onClick:()=>A(e.id||0),className:"text-indigo-600 hover:text-indigo-900 mr-3",title:"Edit",children:"✏️"}),t.jsx("button",{onClick:()=>F(e.id||0),className:"text-red-600 hover:text-red-900",title:"Delete",children:"🗑️"})]})]},e.id))})]})})})]})};export{K as default};
