import{r as n,a as _,u as $,b as i,j as e,L as A}from"./index-Cn6DFgxh.js";import{B as D}from"./Button-DbIH54Da.js";import{F as L}from"./PlusIcon-Cy10Ib0F.js";import{F as E}from"./PrinterIcon-DBhoGpVG.js";import{F as S}from"./TrashIcon-COscQm6o.js";function R({title:s,titleId:c,...l},h){return n.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:h,"aria-labelledby":c},l),s?n.createElement("title",{id:c},s):null,n.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0 1 15.75 21H5.25A2.25 2.25 0 0 1 3 18.75V8.25A2.25 2.25 0 0 1 5.25 6H10"}))}const F=n.forwardRef(R),x="http://168.231.122.33:4000/api/delivery-chalans",u="http://168.231.122.33:4000/api/delivery-chalan-items",q=()=>{const{showAlert:s}=_(),c=$(),[l,h]=n.useState([]),[v,b]=n.useState(!0),[d,w]=n.useState(""),[y,p]=n.useState([]);n.useEffect(()=>{j()},[]),n.useEffect(()=>{if(!d.trim()){p(l);return}const t=d.toLowerCase(),a=l.filter(r=>r.chalan_number.toLowerCase().includes(t)||r.party_name.toLowerCase().includes(t)||r.chalan_date.includes(t));p(a)},[d,l]);const j=async()=>{b(!0);try{const a=(await i.get(x)).data.map(r=>({...r,chalan_date:new Date(r.chalan_date).toLocaleDateString()}));h(a),p(a)}catch(t){console.error("Error fetching delivery chalans:",t),s("Failed to load delivery chalans","error")}finally{b(!1)}},N=async t=>{if(window.confirm("Are you sure you want to delete this delivery chalan? This action cannot be undone."))try{const a=await i.get(`${u}?chalan_id=${t}`);for(const r of a.data)await i.delete(`${u}/${r.id}`);await i.delete(`${x}/${t}`),h(r=>r.filter(g=>g.id!==t)),s("Delivery chalan deleted successfully","success")}catch(a){console.error("Error deleting delivery chalan:",a),s("Failed to delete delivery chalan","error")}},C=async t=>{try{const r=(await i.get(`${x}/${t}`)).data,f=(await i.get(`${u}?chalan_id=${t}`)).data,P={...r,items:f},o=window.open("","_blank");o?(o.document.write("<html><head><title>Delivery Chalan</title>"),o.document.write("<style>"),o.document.write(`
          /* Print styles for Delivery Chalan */
          @page {
            size: A4;
            margin: 0.5cm;
          }
          
          body, html {
            margin: 0;
            padding: 0;
            background: white;
            font-size: 12pt;
            color: black;
            font-family: Arial, sans-serif;
          }

          /* Chalan container */
          .print-chalan {
            width: 100%;
            max-width: 100%;
            padding: 20px;
            box-sizing: border-box;
          }

          /* Chalan header */
          .print-header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
          }

          /* Company name */
          .company-name {
            font-size: 24pt;
            font-weight: bold;
            margin-bottom: 5px;
          }

          /* Chalan info */
          .chalan-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #000;
          }

          /* Table styles */
          .print-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
          }

          .print-table th, .print-table td {
            border: 1px solid #000;
            padding: 8px;
          }

          .print-table th {
            background-color: #f2f2f2;
            text-align: left;
            font-weight: bold;
          }

          /* Total row */
          .total-row {
            font-weight: bold;
          }

          /* Signature section */
          .signature-section {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
          }

          .signature-box {
            border-top: 1px solid #000;
            width: 200px;
            padding-top: 5px;
            text-align: center;
          }

          /* Hide page elements when printing */
          @media print {
            body {
              margin: 0;
              padding: 0;
            }
            
            .no-print {
              display: none;
            }
          }
          
          /* Print controls */
          .print-controls {
            padding: 15px;
            background-color: #f0f4f8;
            border-bottom: 1px solid #ccc;
            text-align: center;
          }
          
          .print-button {
            background-color: #4CAF50;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            margin-right: 10px;
          }
          
          .print-button:hover {
            background-color: #45a049;
          }
          
          .close-button {
            background-color: #f44336;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
          }
          
          .close-button:hover {
            background-color: #d32f2f;
          }
        `),o.document.write("</style></head><body>"),o.document.write(`
          <div class="print-controls no-print">
            <button class="print-button" onclick="window.print()">Print</button>
            <button class="close-button" onclick="window.close()">Close</button>
          </div>
        `),o.document.write(`
          <div class="print-chalan">
            <div class="print-header">
              <div class="company-name">KATHA SALES</div>
              <div>Delivery Chalan</div>
            </div>
            
            <div class="chalan-info">
              <div>
                <div><strong>Chalan Number:</strong> ${r.chalan_number}</div>
                <div><strong>Date:</strong> ${r.chalan_date}</div>
              </div>
              <div>
                <div><strong>Party Name:</strong> ${r.party_name}</div>
              </div>
            </div>
            
            <table class="print-table">
              <thead>
                <tr>
                  <th>Sr. No.</th>
                  <th>Item Code</th>
                  <th>Item Name</th>
                  <th>Quantity</th>
                </tr>
              </thead>
              <tbody>
                ${f.map((m,k)=>`
                  <tr>
                    <td>${k+1}</td>
                    <td>${m.item_code||""}</td>
                    <td>${m.item_name}</td>
                    <td>${m.quantity}</td>
                  </tr>
                `).join("")}
              </tbody>
              <tfoot>
                <tr class="total-row">
                  <td colspan="3" style="text-align: right;"><strong>Total Quantity:</strong></td>
                  <td><strong>${r.total_quantity}</strong></td>
                </tr>
              </tfoot>
            </table>
            
            <div class="signature-section">
              <div class="signature-box">Authorized Signature</div>
              <div class="signature-box">Received By</div>
            </div>
          </div>
        `),o.document.write("</body></html>"),o.document.close()):s("Could not open print window. Please check if pop-up is blocked.","error")}catch(a){console.error("Error printing delivery chalan:",a),s("Failed to print delivery chalan","error")}};return v?e.jsxs("div",{className:"flex items-center justify-center h-64",children:[e.jsx("div",{className:"animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"}),e.jsx("p",{className:"ml-3 text-gray-600",children:"Loading delivery chalans..."})]}):e.jsxs("div",{className:"bg-white rounded-lg shadow-md p-6",children:[e.jsxs("div",{className:"flex justify-between items-center mb-6",children:[e.jsx("h2",{className:"text-xl font-semibold text-gray-800",children:"Delivery Chalans"}),e.jsx(A,{to:"/forms/delivery-chalan-form",children:e.jsxs(D,{className:"flex items-center bg-primary text-white px-4 py-2 rounded-md hover:bg-primary-dark transition-colors",children:[e.jsx(L,{className:"h-5 w-5 mr-2"}),"New Delivery Chalan"]})})]}),e.jsx("div",{className:"mb-6",children:e.jsx("input",{type:"text",placeholder:"Search by chalan number, party name, or date...",value:d,onChange:t=>w(t.target.value),className:"w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"})}),e.jsx("div",{className:"overflow-x-auto",children:y.length===0?e.jsx("p",{className:"text-center py-4 text-gray-500",children:d?"No delivery chalans found matching your search":'No delivery chalans found. Click "New Delivery Chalan" to create one.'}):e.jsxs("table",{className:"min-w-full border-collapse",children:[e.jsx("thead",{children:e.jsxs("tr",{className:"bg-gray-100",children:[e.jsx("th",{className:"py-2 px-4 text-left border",children:"Chalan Number"}),e.jsx("th",{className:"py-2 px-4 text-left border",children:"Date"}),e.jsx("th",{className:"py-2 px-4 text-left border",children:"Party Name"}),e.jsx("th",{className:"py-2 px-4 text-right border",children:"Total Quantity"}),e.jsx("th",{className:"py-2 px-4 text-center border",children:"Actions"})]})}),e.jsx("tbody",{children:y.map(t=>e.jsxs("tr",{className:"hover:bg-gray-50",children:[e.jsx("td",{className:"py-2 px-4 border",children:t.chalan_number}),e.jsx("td",{className:"py-2 px-4 border",children:t.chalan_date}),e.jsx("td",{className:"py-2 px-4 border",children:t.party_name}),e.jsx("td",{className:"py-2 px-4 text-right border",children:t.total_quantity}),e.jsx("td",{className:"py-2 px-4 text-center border",children:e.jsxs("div",{className:"flex justify-center space-x-2",children:[e.jsx("button",{onClick:()=>c(`/forms/delivery-chalan-form/${t.id}`),title:"Edit",className:"text-blue-600 hover:text-blue-800",children:e.jsx(F,{className:"h-5 w-5"})}),e.jsx("button",{onClick:()=>C(t.id),title:"Print",className:"text-green-600 hover:text-green-800",children:e.jsx(E,{className:"h-5 w-5"})}),e.jsx("button",{onClick:()=>N(t.id),title:"Delete",className:"text-red-600 hover:text-red-800",children:e.jsx(S,{className:"h-5 w-5"})})]})})]},t.id))})]})})]})};export{q as default};
