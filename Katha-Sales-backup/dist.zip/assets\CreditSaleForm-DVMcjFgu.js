import{u as ue,c as pe,a as he,r as i,d as ge,b as c,j as e}from"./index-Cn6DFgxh.js";import{B as R}from"./Button-DbIH54Da.js";import{F as xe,a as fe,h as be}from"./itemLookup-B-tAzo2_.js";import{F as ye}from"./PlusIcon-Cy10Ib0F.js";const ve="http://localhost:4000/api/items",j="http://localhost:4000/api/creditsales",y="http://localhost:4000/api/creditsale-items",Se=()=>{const v=ue(),{id:p}=pe(),{showAlert:l}=he(),g=i.useRef(null),U=i.useRef(null),W=i.useRef(null),[C,H]=i.useState(!1),[G,E]=i.useState(!1),[m,we]=i.useState(!!p),[x,$]=i.useState(!1),[A,k]=i.useState(""),[q,B]=i.useState(new Date().toISOString().split("T")[0]),[_,M]=i.useState(""),[w,O]=i.useState("MRP Sales"),[V,J]=i.useState([]),[u,P]=i.useState([]),[I,N]=i.useState(""),[S,T]=i.useState(null),[n,h]=i.useState({item_id:0,item_name:"",item_code:"",quantity:1,rate:0,amount:0}),[f,F]=i.useState({name:"",lastCost:0,lastPurchaseDate:""}),[Q,X]=i.useState(0),[L,Y]=i.useState(0),Z=["MRP Sales","5% Sales","10% Sales","20% Sales","30% Sales","40% Sales"],ee=["Customer 1","Customer 2","Customer 3","Credit Customer A","Credit Customer B"],te=()=>{H(!C)};i.useEffect(()=>{ae(),(async()=>{m||await se()})(),m&&p&&re(p)},[m,p]);const K=ge();i.useEffect(()=>{const s=new URLSearchParams(K.search).get("newItemCode");s&&(N(s),(async()=>{try{const o=await c.get("http://168.231.122.33:4000/api/item-exact",{params:{code:s.trim()}});o.data&&o.data.item&&(D(o.data.item),(o.data.lastCost||o.data.lastPurchaseDate)&&F({name:o.data.item.item_name,lastCost:o.data.lastCost||0,lastPurchaseDate:o.data.lastPurchaseDate||"No purchase"}),g.current&&g.current.focus())}catch(o){console.error("Error fetching new item:",o),l("Error fetching the newly added item","error")}})(),v("/forms/creditsale-form",{replace:!0}))},[K]);const se=async()=>{if(!m)try{const a=((await c.get(j)).data||[]).map(r=>r.invoice_number).filter(r=>/^\d+$/.test(r)).map(r=>parseInt(r,10)),d=(a.length>0?Math.max(...a):0)+1;k(d.toString())}catch(t){console.error("Error generating invoice number:",t),k("1")}},ae=async()=>{E(!0);try{const s=(await c.get(ve)).data.map(a=>(a.item_code!==void 0&&a.item_code!==null&&(a.item_code=a.item_code.toString().trim()),a));J(s),console.log(`Loaded ${s.length} items from backend API`)}catch(t){console.error("Error loading items:",t),l("Failed to load items from server","error")}finally{E(!1)}},re=async t=>{E(!0);try{const a=(await c.get(`${j}/${t}`)).data;k(a.invoice_number),B(a.invoice_date),M(a.customer_name),O(a.sales_type);const d=(await c.get(`${y}?sale_id=${t}`)).data.map(r=>({id:r.id,item_id:r.item_id,item_name:r.item_name,item_code:r.item_code||"",quantity:r.quantity,rate:r.rate,amount:r.amount}));P(d)}catch(s){console.error("Error fetching credit sale for editing:",s),l("Failed to load credit sale data","error"),v("/lists/creditsale-list")}finally{E(!1)}};i.useEffect(()=>{const t=u.reduce((s,a)=>s+a.amount,0);X(t),Y(t)},[u]);const z=t=>Number.isInteger(t)?t.toString():t.toFixed(2).replace(/\.00$/,"").replace(/\.(\d)0$/,".$1"),oe=async t=>{const s=t.target.value.trim();N(s),s===""&&(h({item_id:0,item_name:"",item_code:"",quantity:1,rate:0,amount:0}),F({name:"",lastCost:0,lastPurchaseDate:""}))},ie=t=>{be(t,I,s=>{var a;console.log("Exact match found on Tab/Enter:",s.item.item_name),F({name:s.item.item_name,lastCost:s.lastCost||0,lastPurchaseDate:s.lastPurchaseDate||"No purchase"}),D(s.item),t.key==="Enter"&&((a=document.getElementById("add-item-button"))==null||a.click())},s=>{console.error("Error in exact item lookup:",s),l("Item not found with this exact code","error"),h({item_id:0,item_name:"",item_code:I,quantity:1,rate:0,amount:0}),F({name:"",lastCost:0,lastPurchaseDate:""})})},D=t=>{let s=0;if(w==="MRP Sales")s=t.mrp||0;else{const o=w.match(/(\d+)% Sales/);if(o&&o[1]){const d=parseInt(o[1],10);if(f.lastCost&&f.lastCost>0)s=f.lastCost+f.lastCost*d/100;else{const r=t.opening_cost||0;s=r+r*d/100}}else s=t.mrp||0}const a=s;h({item_id:t.id,item_name:t.item_name,item_code:t.item_code||"",quantity:1,rate:s,amount:a})};i.useEffect(()=>{if(n.item_id){const t=n.quantity,s=n.rate,a=t*s;h(o=>({...o,amount:a}))}},[n.quantity,n.rate]),i.useEffect(()=>{if(n.item_id){const t=V.find(s=>s.id===n.item_id);t&&D(t)}},[w]);const ne=()=>{if(n.item_id===0){l("Please select an item","error");return}if(n.quantity<=0){l("Quantity must be greater than zero","error");return}if(n.rate<=0){l("Rate must be greater than zero","error");return}S!==null?(P(t=>t.map(s=>s.id===S?{...n,id:S}:s)),T(null)):P(t=>[...t,{...n,id:Date.now()}]),h({item_id:0,item_name:"",item_code:"",quantity:1,rate:0,amount:0}),N(""),g.current&&g.current.focus()},de=t=>{if(t){const s=u.find(a=>a.id===t);s&&(h(s),T(t),s.item_code&&N(s.item_code),g.current&&g.current.focus())}},le=t=>{t&&(P(s=>s.filter(a=>a.id!==t)),S===t&&(T(null),h({item_id:0,item_name:"",item_code:"",quantity:1,rate:0,amount:0}),N("")))},ce=async()=>{if(!_){l("Please select a customer","error");return}if(u.length===0){l("Please add at least one item","error");return}if(!x){$(!0);try{const t={invoice_number:A,invoice_date:q,customer_name:_,sales_type:w,subtotal:Q,grand_total:L};let s;if(m&&p){await c.put(`${j}/${p}`,t),s=parseInt(p);const a=await c.get(`${y}?sale_id=${s}`);for(const o of a.data)await c.delete(`${y}/${o.id}`)}else s=(await c.post(j,t)).data.id;for(const a of u){const o={sale_id:s,item_id:a.item_id,item_name:a.item_name,item_code:a.item_code||"",quantity:a.quantity,rate:a.rate,amount:a.amount};await c.post(y,o)}l(m?"Credit Sale updated successfully!":"Credit Sale saved successfully!","success"),setTimeout(()=>{v("/lists/creditsale-list")},500)}catch(t){console.error("Error saving credit sale:",t),l(m?"Failed to update credit sale":"Failed to save credit sale","error")}finally{$(!1)}}},me=async()=>{if(!_){l("Please select a customer","error");return}if(u.length===0){l("Please add at least one item","error");return}if(!x){$(!0);try{const t={invoice_number:A,invoice_date:q,customer_name:_,sales_type:w,subtotal:Q,grand_total:L};let s,a={...t};if(m&&p){await c.put(`${j}/${p}`,t),s=parseInt(p),a.id=s;const r=await c.get(`${y}?sale_id=${s}`);for(const b of r.data)await c.delete(`${y}/${b.id}`)}else s=(await c.post(j,t)).data.id,a.id=s;for(const r of u){const b={sale_id:s,item_id:r.item_id,item_name:r.item_name,item_code:r.item_code||"",quantity:r.quantity,rate:r.rate,amount:r.amount};await c.post(y,b)}l(m?"Credit Sale updated successfully!":"Credit Sale saved successfully!","success");const o={...a,items:u},d=window.open("","_blank");d?(d.document.write("<html><head><title>Credit Sale Invoice</title>"),d.document.write("<style>"),d.document.write(`
          /* Print styles for Credit Sale Invoice */
          @page {
            size: A4;
            margin: 0.5cm;
          }
          
          body, html {
            margin: 0;
            padding: 0;
            background: white;
            font-size: 12pt;
            color: black;
            font-family: Arial, sans-serif;
          }

          /* Invoice container */
          .print-invoice {
            width: 100%;
            max-width: 100%;
            padding: 20px;
            box-sizing: border-box;
          }

          /* Invoice header */
          .print-header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
          }

          /* Company name */
          .company-name {
            font-size: 24pt;
            font-weight: bold;
            margin-bottom: 5px;
          }

          /* Invoice info */
          .invoice-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #000;
          }

          /* Table styles */
          .print-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
          }

          .print-table th, .print-table td {
            border: 1px solid #000;
            padding: 8px;
          }

          .print-table th {
            background-color: #f2f2f2;
            text-align: left;
            font-weight: bold;
          }

          /* Total row */
          .total-row {
            font-weight: bold;
          }

          /* Signature section */
          .signature-section {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
          }

          .signature-box {
            border-top: 1px solid #000;
            width: 200px;
            padding-top: 5px;
            text-align: center;
          }

          /* Fullscreen form */
          .fullscreen-form {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            z-index: 9999;
            overflow: auto;
          }

          /* Hide page elements when printing */
          @media print {
            body {
              margin: 0;
              padding: 0;
            }
            
            .no-print {
              display: none;
            }
          }
          
          /* Print controls */
          .print-controls {
            padding: 15px;
            background-color: #f0f4f8;
            border-bottom: 1px solid #ccc;
            text-align: center;
          }
          
          .print-button {
            background-color: #4CAF50;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            margin-right: 10px;
          }
          
          .print-button:hover {
            background-color: #45a049;
          }
          
          .close-button {
            background-color: #f44336;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
          }
          
          .close-button:hover {
            background-color: #d32f2f;
          }
        `),d.document.write("</style></head><body>"),d.document.write(`
          <div class="print-controls no-print">
            <button class="print-button" onclick="window.print()">Print</button>
            <button class="close-button" onclick="window.close()">Close</button>
          </div>
        `),d.document.write(`
          <div class="print-invoice">
            <div class="print-header">
              <div class="company-name">KATHA SALES</div>
              <div>Credit Sale Invoice</div>
            </div>
            
            <div class="invoice-info">
              <div>
                <div><strong>Invoice Number:</strong> ${o.invoice_number}</div>
                <div><strong>Date:</strong> ${new Date(o.invoice_date).toLocaleDateString()}</div>
                <div><strong>Sales Type:</strong> ${o.sales_type}</div>
              </div>
              <div>
                <div><strong>Customer:</strong> ${o.customer_name}</div>
              </div>
            </div>
            
            <table class="print-table">
              <thead>
                <tr>
                  <th>Sr. No.</th>
                  <th>Item Code</th>
                  <th>Item Name</th>
                  <th>Qty</th>
                  <th>Rate</th>
                  <th>Amount</th>
                </tr>
              </thead>
              <tbody>
                ${o.items.map((r,b)=>`
                  <tr>
                    <td>${b+1}</td>
                    <td>${r.item_code||""}</td>
                    <td>${r.item_name}</td>
                    <td>${r.quantity}</td>
                    <td>${(r.rate||0).toFixed(2)}</td>
                    <td>${(r.amount||0).toFixed(2)}</td>
                  </tr>
                `).join("")}
              </tbody>
              <tfoot>
                <tr class="total-row">
                  <td colspan="3" style="text-align: right;"><strong>Total:</strong></td>
                  <td style="text-align: center;"><strong>${o.items.reduce((r,b)=>r+b.quantity,0)}</strong></td>
                  <td></td>
                  <td style="text-align: right;"><strong>${o.grand_total.toFixed(2)}</strong></td>
                </tr>
              </tfoot>
            </table>
            
            <div class="signature-section">
              <div class="signature-box">Authorized Signature</div>
              <div class="signature-box">Received By</div>
            </div>
          </div>
        `),d.document.write("</body></html>"),d.document.close(),d.onafterprint=()=>{setTimeout(()=>{v("/lists/creditsale-list")},500)}):(l("Could not open print window. Please check if pop-up is blocked.","error"),setTimeout(()=>{v("/lists/creditsale-list")},500))}catch(t){console.error("Error saving and printing credit sale:",t),l(m?"Failed to update and print credit sale":"Failed to save and print credit sale","error")}finally{$(!1)}}};return G?e.jsxs("div",{className:"flex items-center justify-center h-64",children:[e.jsx("div",{className:"animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"}),e.jsx("p",{className:"ml-3 text-gray-600",children:"Loading..."})]}):e.jsxs("div",{ref:W,className:`bg-white rounded-lg shadow-md ${C?"fullscreen-form":""}`,children:[e.jsxs("div",{className:"bg-primary text-white px-6 py-4 rounded-t-lg flex justify-between items-center",children:[e.jsx("h2",{className:"text-xl font-semibold",children:m?"Edit Credit Sale Invoice":"New Credit Sale Invoice"}),e.jsx("div",{className:"flex items-center space-x-2",children:e.jsx("button",{onClick:te,className:"bg-white/20 hover:bg-white/30 text-white p-1.5 rounded-md transition-colors",title:C?"Exit Fullscreen":"Enter Fullscreen",children:C?e.jsx(xe,{className:"h-5 w-5"}):e.jsx(fe,{className:"h-5 w-5"})})})]}),e.jsxs("div",{className:"p-6",children:[e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-4 gap-6 mb-6",children:[e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Sales Type"}),e.jsx("select",{value:w,onChange:t=>O(t.target.value),className:"form-select w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50",children:Z.map((t,s)=>e.jsx("option",{value:t,children:t},s))})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Invoice No."}),e.jsx("input",{type:"text",value:A,onChange:t=>k(t.target.value),className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Invoice Date"}),e.jsx("input",{type:"date",value:q,onChange:t=>B(t.target.value),className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Customer Name"}),e.jsxs("select",{value:_,onChange:t=>M(t.target.value),className:"form-select w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50",children:[e.jsx("option",{value:"",children:"-- Select Customer --"}),ee.map((t,s)=>e.jsx("option",{value:t,children:t},s))]})]})]}),e.jsxs("div",{className:"bg-gray-50 p-4 rounded-lg mb-6",children:[e.jsx("h3",{className:"text-lg font-medium text-gray-700 mb-4",children:"Item Details"}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-12 gap-3 mb-5",children:[e.jsxs("div",{className:"md:col-span-4 relative",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Item Code"}),e.jsxs("div",{className:"flex",children:[e.jsx("input",{ref:g,type:"text",value:I,onChange:oe,onKeyDown:ie,className:`form-input w-full rounded-l-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 ${n.item_id?"border-green-500":I&&!n.item_id?"border-red-500":""}`,placeholder:"Enter item code or barcode"}),e.jsx("button",{type:"button",onClick:()=>{window.open("http://localhost:5173/forms/item?returnTo=credit","_blank");const t=s=>{if(s.data&&s.data.newItemCode){const a=s.data.newItemCode;N(a),(async()=>{try{const d=await c.get("http://168.231.122.33:4000/api/item-exact",{params:{code:a.trim()}});d.data&&d.data.item&&(D(d.data.item),g.current&&g.current.focus())}catch(d){console.error("Error fetching new item:",d),l("Error fetching the newly added item","error")}})(),window.removeEventListener("message",t)}};window.addEventListener("message",t)},className:"bg-green-600 text-white px-3 rounded-r-md hover:bg-green-700 flex items-center justify-center",title:"Add New Item",children:e.jsx(ye,{className:"h-5 w-5"})})]}),I&&!n.item_id&&e.jsx("p",{className:"text-xs text-red-500 mt-1",children:"Item not found. Try adding it."}),f.name&&e.jsxs("div",{className:"mt-2 p-2 bg-blue-50 rounded-md text-sm",children:[e.jsx("div",{className:"font-semibold text-blue-800",children:"Item Details:"}),e.jsxs("div",{className:"grid grid-cols-3 gap-2 mt-1",children:[e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"Name:"})," ",f.name]}),e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"Per Item Cost:"})," ₹",parseFloat(f.lastCost).toFixed(2)]}),e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"Last Purchase:"})," ",f.lastPurchaseDate]})]})]})]}),e.jsxs("div",{className:"md:col-span-4",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Item Name"}),e.jsx("input",{type:"text",value:n.item_name,readOnly:!0,className:"form-input w-full rounded-md border-gray-300 bg-gray-100 shadow-sm"})]}),e.jsxs("div",{className:"md:col-span-1",style:{maxWidth:"100px"},children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Qty"}),e.jsx("input",{type:"number",min:"1",value:n.quantity,onChange:t=>{const s=parseInt(t.target.value)||0;h({...n,quantity:s})},className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"})]}),e.jsxs("div",{className:"md:col-span-1",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Rate"}),e.jsx("input",{type:"number",min:"0",step:"0.01",value:n.rate,onChange:t=>{const s=parseFloat(t.target.value)||0;h({...n,rate:s})},className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"})]}),e.jsxs("div",{className:"md:col-span-2",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Amount"}),e.jsx("input",{type:"number",step:"0.01",value:n.amount,onChange:t=>{const s=parseFloat(t.target.value)||0,a=n.quantity||1,o=a>0?s/a:0;h({...n,amount:s,rate:o})},className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"})]})]}),e.jsx("div",{className:"flex justify-end",children:e.jsx(R,{id:"add-item-button",onClick:ne,className:"bg-primary text-white px-6 py-2 rounded-md hover:bg-primary-dark transition-colors",children:S!==null?"Update Item":"Add Item"})})]}),e.jsx("div",{className:"mb-6 overflow-x-auto",children:e.jsxs("table",{className:"w-full border-collapse",children:[e.jsx("thead",{children:e.jsxs("tr",{className:"bg-gray-100",children:[e.jsx("th",{className:"py-2 px-4 text-left border",children:"Item Code"}),e.jsx("th",{className:"py-2 px-4 text-left border",children:"Item Name"}),e.jsx("th",{className:"py-2 px-4 text-right border",children:"Qty"}),e.jsx("th",{className:"py-2 px-4 text-right border",children:"Rate"}),e.jsx("th",{className:"py-2 px-4 text-right border",children:"Amount"}),e.jsx("th",{className:"py-2 px-4 text-center border",children:"Actions"})]})}),e.jsx("tbody",{children:u.length===0?e.jsx("tr",{children:e.jsx("td",{colSpan:6,className:"py-4 text-center text-gray-500 border",children:"No items added yet. Use the form above to add items."})}):u.map(t=>e.jsxs("tr",{className:"hover:bg-gray-50",children:[e.jsx("td",{className:"py-2 px-4 border",children:t.item_code}),e.jsx("td",{className:"py-2 px-4 border",children:t.item_name}),e.jsx("td",{className:"py-2 px-4 text-right border",children:t.quantity}),e.jsx("td",{className:"py-2 px-4 text-right border",children:z(t.rate)}),e.jsx("td",{className:"py-2 px-4 text-right border",children:z(t.amount)}),e.jsxs("td",{className:"py-2 px-4 text-center border",children:[e.jsx("button",{onClick:()=>de(t.id),className:"text-blue-600 hover:text-blue-800 mr-2",children:"Edit"}),e.jsx("button",{onClick:()=>le(t.id),className:"text-red-600 hover:text-red-800",children:"Delete"})]})]},t.id))}),e.jsx("tfoot",{children:e.jsxs("tr",{className:"bg-gray-100 font-medium",children:[e.jsx("td",{colSpan:2,className:"text-right pr-4 py-2 border",children:"Total:"}),e.jsx("td",{className:"text-right pr-4 border",children:u.reduce((t,s)=>t+s.quantity,0)}),e.jsx("td",{className:"text-right pr-4 border"}),e.jsx("td",{className:"text-right pr-4 border",children:z(L)}),e.jsx("td",{className:"border"})]})})]})}),e.jsxs("div",{className:"flex justify-end space-x-4",children:[e.jsx(R,{onClick:()=>v("/lists/creditsale-list"),className:"bg-gray-200 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-300 transition-colors",children:"Cancel"}),e.jsx(R,{onClick:ce,disabled:x,className:`bg-green-600 text-white px-6 py-2 rounded-md transition-colors ${x?"opacity-70 cursor-not-allowed":"hover:bg-green-700 cursor-pointer"}`,children:x?"Saving...":m?"Update":"Save"}),e.jsx(R,{onClick:me,disabled:x,className:`bg-blue-600 text-white px-6 py-2 rounded-md transition-colors ${x?"opacity-70 cursor-not-allowed":"hover:bg-blue-700 cursor-pointer"}`,children:x?"Processing...":"Save & Print"})]})]}),e.jsx("div",{ref:U,className:"hidden"})]})};export{Se as default};
