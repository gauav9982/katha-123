import{a as L,r as n,b as m,j as t,F as k,L as j}from"./index-Cn6DFgxh.js";import{A as N}from"./config-DOZbGk3J.js";import{F as R}from"./ArrowPathIcon-CPsqOFvf.js";import{F as T}from"./PlusIcon-Cy10Ib0F.js";import{F as E}from"./PrinterIcon-DBhoGpVG.js";import{F as D}from"./PencilIcon-DutxVAEw.js";import{F as P}from"./TrashIcon-COscQm6o.js";const f=N.CASHSALES,y=N.CASHSALE_ITEMS,K=()=>{const{showAlert:d}=L(),[x,S]=n.useState([]),[h,p]=n.useState([]),[$,w]=n.useState(!0),[l,A]=n.useState(""),[b,v]=n.useState(!1);n.useEffect(()=>{g()},[]);const g=async()=>{var e,i;w(!0);try{console.log("Making API request to:",f);const r=await m.get(f),s=r.data;console.log("API Response:",{status:r.status,statusText:r.statusText,dataLength:Array.isArray(s)?s.length:"Not an array",data:s});const o=s.sort((a,c)=>{const I=new Date(a.invoice_date).getTime();return new Date(c.invoice_date).getTime()-I});S(o),p(o),console.log(`Loaded ${o.length} cash sales`)}catch(r){console.error("Error loading cash sales:",r),console.error("Error details:",{message:r.message,response:(e=r.response)==null?void 0:e.data,status:(i=r.response)==null?void 0:i.status}),d("Failed to load cash sales from server","error")}finally{w(!1)}};n.useEffect(()=>{if(l.trim()==="")p(x);else{const e=l.toLowerCase().trim(),i=x.filter(r=>r.invoice_number.toString().toLowerCase().includes(e)||r.customer_name.toLowerCase().includes(e));p(i)}},[l,x]);const _=e=>new Date(e).toLocaleDateString(),u=e=>new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",minimumFractionDigits:2}).format(e),C=async e=>{if(!b&&window.confirm("Are you sure you want to delete this cash sale? This action cannot be undone.")){v(!0);try{const r=(await m.get(`${y}?sale_id=${e}`)).data;for(const s of r)await m.delete(`${y}/${s.id}`);await m.delete(`${f}/${e}`),d("Cash sale deleted successfully","success"),g()}catch(i){console.error("Error deleting cash sale:",i),d("Failed to delete cash sale","error")}finally{v(!1)}}},F=async e=>{try{const r=(await m.get(`${y}?sale_id=${e.id}`)).data.map(a=>({...a,total:a.amount+(a.gst_amount||0)})),s={...e,items:r},o=window.open("","_blank");o?(o.document.write("<html><head><title>Cash Sale Invoice</title>"),o.document.write("<style>"),o.document.write(`
          /* Print styles for Cash Sale Invoice */
          @page {
            size: A4;
            margin: 0.5cm;
          }
          
          body, html {
            margin: 0;
            padding: 0;
            background: white;
            font-size: 12pt;
            color: black;
            font-family: Arial, sans-serif;
          }

          /* Invoice container */
          .print-invoice {
            width: 100%;
            max-width: 100%;
            padding: 20px;
            box-sizing: border-box;
          }

          /* Invoice header */
          .print-header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
          }

          /* Company name */
          .company-name {
            font-size: 24pt;
            font-weight: bold;
            margin-bottom: 5px;
          }

          /* Invoice info */
          .invoice-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #000;
          }

          /* Table styles */
          .print-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
          }

          .print-table th, .print-table td {
            border: 1px solid #000;
            padding: 8px;
          }

          .print-table th {
            background-color: #f2f2f2;
            text-align: left;
            font-weight: bold;
          }

          /* Total row */
          .total-row {
            font-weight: bold;
          }

          /* Signature section */
          .signature-section {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
          }

          .signature-box {
            border-top: 1px solid #000;
            width: 200px;
            padding-top: 5px;
            text-align: center;
          }
        `),o.document.write("</style></head><body>"),o.document.write(`
          <div class="print-invoice">
            <div class="print-header">
              <div class="company-name">KATHA SALES</div>
              <div>Cash Sale Invoice</div>
            </div>
            
            <div class="invoice-info">
              <div>
                <div><strong>Invoice Number:</strong> ${s.invoice_number}</div>
                <div><strong>Date:</strong> ${new Date(s.invoice_date).toLocaleDateString()}</div>
              </div>
              <div>
                <div><strong>Customer:</strong> ${s.customer_name}</div>
              </div>
            </div>
            
            <table class="print-table">
              <thead>
                <tr>
                  <th>Sr. No.</th>
                  <th>Item Code</th>
                  <th>Item Name</th>
                  <th>Qty</th>
                  <th>Rate</th>
                  <th>Amount</th>
                  <th>GST %</th>
                  <th>GST Amount</th>
                  <th>Total</th>
                </tr>
              </thead>
              <tbody>
                ${s.items.map((a,c)=>`
                  <tr>
                    <td>${c+1}</td>
                    <td>${a.item_code||""}</td>
                    <td>${a.item_name}</td>
                    <td>${a.quantity}</td>
                    <td>${(a.rate||0).toFixed(2)}</td>
                    <td>${(a.amount||0).toFixed(2)}</td>
                    <td>${a.gst_percentage}%</td>
                    <td>${(a.gst_amount||0).toFixed(2)}</td>
                    <td>${(a.total||0).toFixed(2)}</td>
                  </tr>
                `).join("")}
              </tbody>
              <tfoot>
                <tr class="total-row">
                  <td colspan="3" style="text-align: right;"><strong>Subtotal:</strong></td>
                  <td style="text-align: center;"><strong>${s.items.reduce((a,c)=>a+c.quantity,0)}</strong></td>
                  <td></td>
                  <td style="text-align: right;"><strong>${s.subtotal.toFixed(2)}</strong></td>
                  <td></td>
                  <td style="text-align: right;"><strong>${s.total_gst.toFixed(2)}</strong></td>
                  <td style="text-align: right;"><strong>${s.grand_total.toFixed(2)}</strong></td>
                </tr>
                <tr class="total-row">
                  <td colspan="8" style="text-align: right;"><strong>Grand Total:</strong></td>
                  <td style="text-align: right;"><strong>${s.grand_total.toFixed(2)}</strong></td>
                </tr>
              </tfoot>
            </table>
            
            <div class="signature-section">
              <div class="signature-box">Authorized Signature</div>
              <div class="signature-box">Received By</div>
            </div>
          </div>
        `),o.document.write("</body></html>"),o.document.close(),setTimeout(()=>{o.print()},500)):d("Could not open print window. Please check if pop-up is blocked.","error")}catch(i){console.error("Error printing cash sale:",i),d("Failed to print cash sale","error")}};return $?t.jsxs("div",{className:"flex items-center justify-center h-64",children:[t.jsx("div",{className:"animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"}),t.jsx("p",{className:"ml-3 text-gray-600",children:"Loading Cash Sales..."})]}):t.jsxs("div",{className:"bg-white shadow-md rounded-lg overflow-hidden",children:[t.jsxs("div",{className:"bg-primary text-white px-6 py-4 flex flex-col md:flex-row justify-between items-start md:items-center",children:[t.jsx("h2",{className:"text-xl font-semibold mb-3 md:mb-0",children:"Cash Sales List"}),t.jsxs("div",{className:"flex flex-col md:flex-row space-y-3 md:space-y-0 md:space-x-3 w-full md:w-auto",children:[t.jsxs("div",{className:"relative rounded-md shadow-sm",children:[t.jsx("div",{className:"absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none",children:t.jsx(k,{className:"h-5 w-5 text-gray-400"})}),t.jsx("input",{type:"text",placeholder:"Search by invoice number or customer...",value:l,onChange:e=>A(e.target.value),className:"form-input pl-10 pr-4 py-2 w-full md:w-60 rounded-md text-gray-800 border-gray-300 focus:ring-primary focus:border-primary"})]}),t.jsxs("div",{className:"flex space-x-2",children:[t.jsx("button",{onClick:g,className:"btn flex items-center justify-center bg-white/10 text-white px-4 py-2 rounded-md hover:bg-white/20 transition-colors",title:"Refresh List",children:t.jsx(R,{className:"h-5 w-5"})}),t.jsxs(j,{to:"/forms/cash-sale",className:"btn flex items-center justify-center bg-white text-primary px-4 py-2 rounded-md hover:bg-gray-100 transition-colors",children:[t.jsx(T,{className:"h-5 w-5 mr-1"}),t.jsx("span",{children:"New Cash Sale"})]})]})]})]}),t.jsx("div",{style:{maxHeight:"none",overflow:"visible"},children:t.jsxs("table",{className:"min-w-full bg-white",children:[t.jsx("thead",{className:"bg-gray-100",children:t.jsxs("tr",{children:[t.jsx("th",{className:"py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Invoice #"}),t.jsx("th",{className:"py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Date"}),t.jsx("th",{className:"py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Customer"}),t.jsx("th",{className:"py-3 px-4 text-right text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Subtotal"}),t.jsx("th",{className:"py-3 px-4 text-right text-xs font-medium text-gray-500 uppercase tracking-wider",children:"GST Amount"}),t.jsx("th",{className:"py-3 px-4 text-right text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Grand Total"}),t.jsx("th",{className:"py-3 px-4 text-center text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Actions"})]})}),t.jsx("tbody",{className:"divide-y divide-gray-200",children:h.length===0?t.jsx("tr",{children:t.jsx("td",{colSpan:7,className:"px-4 py-8 text-center text-gray-500",children:l?"No cash sales match your search criteria":"No cash sales found"})}):h.map(e=>t.jsxs("tr",{className:"hover:bg-gray-50",children:[t.jsx("td",{className:"px-4 py-3 whitespace-nowrap",children:e.invoice_number}),t.jsx("td",{className:"px-4 py-3 whitespace-nowrap",children:_(e.invoice_date)}),t.jsx("td",{className:"px-4 py-3",children:e.customer_name}),t.jsx("td",{className:"px-4 py-3 text-right whitespace-nowrap",children:u(e.subtotal)}),t.jsx("td",{className:"px-4 py-3 text-right whitespace-nowrap",children:u(e.total_gst)}),t.jsx("td",{className:"px-4 py-3 text-right whitespace-nowrap font-medium",children:u(e.grand_total)}),t.jsx("td",{className:"px-4 py-3 whitespace-nowrap text-center",children:t.jsxs("div",{className:"flex justify-center space-x-2",children:[t.jsx("button",{onClick:()=>F(e),className:"text-blue-600 hover:text-blue-800",title:"Print",children:t.jsx(E,{className:"h-5 w-5"})}),t.jsx(j,{to:`/forms/cash-sale/${e.id}`,className:"text-indigo-600 hover:text-indigo-800",title:"Edit",children:t.jsx(D,{className:"h-5 w-5"})}),t.jsx("button",{onClick:()=>C(e.id),className:"text-red-600 hover:text-red-800",title:"Delete",disabled:b,children:t.jsx(P,{className:"h-5 w-5"})})]})})]},e.id))})]})}),t.jsx("div",{className:"bg-gray-50 px-4 py-3 flex items-center justify-between border-t border-gray-200",children:t.jsx("div",{children:t.jsxs("p",{className:"text-sm text-gray-700",children:["Showing ",t.jsx("span",{className:"font-medium",children:h.length})," sales"]})})})]})};export{K as default};
