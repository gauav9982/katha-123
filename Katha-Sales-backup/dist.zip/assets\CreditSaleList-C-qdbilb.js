import{a as I,r as n,b as c,j as t,F as A,L as v}from"./index-Cn6DFgxh.js";import{F as k}from"./ArrowPathIcon-CPsqOFvf.js";import{F as D}from"./PlusIcon-Cy10Ib0F.js";import{F as R}from"./PrinterIcon-DBhoGpVG.js";import{F as L}from"./PencilIcon-DutxVAEw.js";import{F as T}from"./TrashIcon-COscQm6o.js";const j="http://168.231.122.33:4000/api/creditsales",f="http://168.231.122.33:4000/api/creditsale-items",Q=()=>{const{showAlert:d}=I(),[x,N]=n.useState([]),[p,h]=n.useState([]),[S,y]=n.useState(!0),[l,$]=n.useState(""),[w,b]=n.useState(!1);n.useEffect(()=>{g()},[]);const g=async()=>{y(!0);try{const i=(await c.get(j)).data.sort((r,a)=>{const s=new Date(r.invoice_date).getTime();return new Date(a.invoice_date).getTime()-s});N(i),h(i),console.log(`Loaded ${i.length} credit sales`)}catch(e){console.error("Error loading credit sales:",e),d("Failed to load credit sales from server","error")}finally{y(!1)}};n.useEffect(()=>{if(l.trim()==="")h(x);else{const e=l.toLowerCase().trim(),o=x.filter(i=>i.invoice_number.toString().toLowerCase().includes(e)||i.customer_name.toLowerCase().includes(e));h(o)}},[l,x]);const F=e=>new Date(e).toLocaleDateString(),u=e=>new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",minimumFractionDigits:2}).format(e),_=async e=>{if(!w&&window.confirm("Are you sure you want to delete this credit sale? This action cannot be undone.")){b(!0);try{const i=(await c.get(`${f}?sale_id=${e}`)).data;for(const r of i)await c.delete(`${f}/${r.id}`);await c.delete(`${j}/${e}`),d("Credit sale deleted successfully","success"),g()}catch(o){console.error("Error deleting credit sale:",o),d("Failed to delete credit sale","error")}finally{b(!1)}}},C=async e=>{try{const i=(await c.get(`${f}?sale_id=${e.id}`)).data.map(s=>({...s,total:s.amount+(s.gst_amount||0)})),r={...e,items:i},a=window.open("","_blank");a?(a.document.write("<html><head><title>Credit Sale Invoice</title>"),a.document.write("<style>"),a.document.write(`
          /* Print styles for Credit Sale Invoice */
          @page {
            size: A4;
            margin: 0.5cm;
          }
          
          body, html {
            margin: 0;
            padding: 0;
            background: white;
            font-size: 12pt;
            color: black;
            font-family: Arial, sans-serif;
          }

          /* Invoice container */
          .print-invoice {
            width: 100%;
            max-width: 100%;
            padding: 20px;
            box-sizing: border-box;
          }

          /* Invoice header */
          .print-header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
          }

          /* Company name */
          .company-name {
            font-size: 24pt;
            font-weight: bold;
            margin-bottom: 5px;
          }

          /* Invoice info */
          .invoice-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #000;
          }

          /* Table styles */
          .print-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
          }

          .print-table th, .print-table td {
            border: 1px solid #000;
            padding: 8px;
          }

          .print-table th {
            background-color: #f2f2f2;
            text-align: left;
            font-weight: bold;
          }

          /* Total row */
          .total-row {
            font-weight: bold;
          }

          /* Signature section */
          .signature-section {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
          }

          .signature-box {
            border-top: 1px solid #000;
            width: 200px;
            padding-top: 5px;
            text-align: center;
          }
        `),a.document.write("</style></head><body>"),a.document.write(`
          <div class="print-invoice">
            <div class="print-header">
              <div class="company-name">KATHA SALES</div>
              <div>Credit Sale Invoice</div>
            </div>
            
            <div class="invoice-info">
              <div>
                <div><strong>Invoice Number:</strong> ${r.invoice_number}</div>
                <div><strong>Date:</strong> ${new Date(r.invoice_date).toLocaleDateString()}</div>
              </div>
              <div>
                <div><strong>Customer:</strong> ${r.customer_name}</div>
              </div>
            </div>
            
            <table class="print-table">
              <thead>
                <tr>
                  <th>Sr. No.</th>
                  <th>Item Code</th>
                  <th>Item Name</th>
                  <th>Qty</th>
                  <th>Rate</th>
                  <th>Amount</th>
                  <th>GST %</th>
                  <th>GST Amount</th>
                  <th>Total</th>
                </tr>
              </thead>
              <tbody>
                ${r.items.map((s,m)=>`
                  <tr>
                    <td>${m+1}</td>
                    <td>${s.item_code||""}</td>
                    <td>${s.item_name}</td>
                    <td>${s.quantity}</td>
                    <td>${(s.rate||0).toFixed(2)}</td>
                    <td>${(s.amount||0).toFixed(2)}</td>
                    <td>${s.gst_percentage}%</td>
                    <td>${(s.gst_amount||0).toFixed(2)}</td>
                    <td>${(s.total||0).toFixed(2)}</td>
                  </tr>
                `).join("")}
              </tbody>
              <tfoot>
                <tr class="total-row">
                  <td colspan="3" style="text-align: right;"><strong>Subtotal:</strong></td>
                  <td style="text-align: center;"><strong>${r.items.reduce((s,m)=>s+m.quantity,0)}</strong></td>
                  <td></td>
                  <td style="text-align: right;"><strong>${r.subtotal.toFixed(2)}</strong></td>
                  <td></td>
                  <td style="text-align: right;"><strong>${r.total_gst.toFixed(2)}</strong></td>
                  <td style="text-align: right;"><strong>${r.grand_total.toFixed(2)}</strong></td>
                </tr>
                <tr class="total-row">
                  <td colspan="8" style="text-align: right;"><strong>Grand Total:</strong></td>
                  <td style="text-align: right;"><strong>${r.grand_total.toFixed(2)}</strong></td>
                </tr>
              </tfoot>
            </table>
            
            <div class="signature-section">
              <div class="signature-box">Authorized Signature</div>
              <div class="signature-box">Received By</div>
            </div>
          </div>
        `),a.document.write("</body></html>"),a.document.close(),setTimeout(()=>{a.print()},500)):d("Could not open print window. Please check if pop-up is blocked.","error")}catch(o){console.error("Error printing credit sale:",o),d("Failed to print credit sale","error")}};return S?t.jsxs("div",{className:"flex items-center justify-center h-64",children:[t.jsx("div",{className:"animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"}),t.jsx("p",{className:"ml-3 text-gray-600",children:"Loading Credit Sales..."})]}):t.jsxs("div",{className:"bg-white shadow-md rounded-lg overflow-hidden",children:[t.jsxs("div",{className:"bg-primary text-white px-6 py-4 flex flex-col md:flex-row justify-between items-start md:items-center",children:[t.jsx("h2",{className:"text-xl font-semibold mb-3 md:mb-0",children:"Credit Sales List"}),t.jsxs("div",{className:"flex flex-col md:flex-row space-y-3 md:space-y-0 md:space-x-3 w-full md:w-auto",children:[t.jsxs("div",{className:"relative rounded-md shadow-sm",children:[t.jsx("div",{className:"absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none",children:t.jsx(A,{className:"h-5 w-5 text-gray-400"})}),t.jsx("input",{type:"text",placeholder:"Search by invoice number or customer...",value:l,onChange:e=>$(e.target.value),className:"form-input pl-10 pr-4 py-2 w-full md:w-60 rounded-md text-gray-800 border-gray-300 focus:ring-primary focus:border-primary"})]}),t.jsxs("div",{className:"flex space-x-2",children:[t.jsx("button",{onClick:g,className:"btn flex items-center justify-center bg-white/10 text-white px-4 py-2 rounded-md hover:bg-white/20 transition-colors",title:"Refresh List",children:t.jsx(k,{className:"h-5 w-5"})}),t.jsxs(v,{to:"/forms/credit-sale",className:"btn flex items-center justify-center bg-white text-primary px-4 py-2 rounded-md hover:bg-gray-100 transition-colors",children:[t.jsx(D,{className:"h-5 w-5 mr-1"}),t.jsx("span",{children:"New Credit Sale"})]})]})]})]}),t.jsx("div",{className:"overflow-x-auto",children:t.jsxs("table",{className:"min-w-full bg-white",children:[t.jsx("thead",{className:"bg-gray-100",children:t.jsxs("tr",{children:[t.jsx("th",{className:"py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Invoice #"}),t.jsx("th",{className:"py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Date"}),t.jsx("th",{className:"py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Customer"}),t.jsx("th",{className:"py-3 px-4 text-right text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Subtotal"}),t.jsx("th",{className:"py-3 px-4 text-right text-xs font-medium text-gray-500 uppercase tracking-wider",children:"GST Amount"}),t.jsx("th",{className:"py-3 px-4 text-right text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Grand Total"}),t.jsx("th",{className:"py-3 px-4 text-center text-xs font-medium text-gray-500 uppercase tracking-wider",children:"Actions"})]})}),t.jsx("tbody",{className:"divide-y divide-gray-200",children:p.length===0?t.jsx("tr",{children:t.jsx("td",{colSpan:7,className:"px-4 py-8 text-center text-gray-500",children:l?"No credit sales match your search criteria":"No credit sales found"})}):p.map(e=>t.jsxs("tr",{className:"hover:bg-gray-50",children:[t.jsx("td",{className:"px-4 py-3 whitespace-nowrap",children:e.invoice_number}),t.jsx("td",{className:"px-4 py-3 whitespace-nowrap",children:F(e.invoice_date)}),t.jsx("td",{className:"px-4 py-3",children:e.customer_name}),t.jsx("td",{className:"px-4 py-3 text-right whitespace-nowrap",children:u(e.subtotal)}),t.jsx("td",{className:"px-4 py-3 text-right whitespace-nowrap",children:u(e.total_gst)}),t.jsx("td",{className:"px-4 py-3 text-right whitespace-nowrap font-medium",children:u(e.grand_total)}),t.jsx("td",{className:"px-4 py-3 whitespace-nowrap text-center",children:t.jsxs("div",{className:"flex justify-center space-x-2",children:[t.jsx("button",{onClick:()=>C(e),className:"text-blue-600 hover:text-blue-800",title:"Print",children:t.jsx(R,{className:"h-5 w-5"})}),t.jsx(v,{to:`/forms/credit-sale/${e.id}`,className:"text-indigo-600 hover:text-indigo-800",title:"Edit",children:t.jsx(L,{className:"h-5 w-5"})}),t.jsx("button",{onClick:()=>_(e.id),className:"text-red-600 hover:text-red-800",title:"Delete",disabled:w,children:t.jsx(T,{className:"h-5 w-5"})})]})})]},e.id))})]})}),t.jsx("div",{className:"bg-gray-50 px-4 py-3 flex items-center justify-between border-t border-gray-200",children:t.jsx("div",{children:t.jsxs("p",{className:"text-sm text-gray-700",children:["Showing ",t.jsx("span",{className:"font-medium",children:p.length})," sales"]})})})]})};export{Q as default};
