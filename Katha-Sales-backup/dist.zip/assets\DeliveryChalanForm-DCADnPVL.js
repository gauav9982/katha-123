import{u as re,c as ne,a as se,r as i,d as ie,b as d,j as e}from"./index-Cn6DFgxh.js";import{B as $}from"./Button-DbIH54Da.js";import{F as oe,a as le,h as de}from"./itemLookup-B-tAzo2_.js";import{F as ce}from"./PlusIcon-Cy10Ib0F.js";const me="http://localhost:4000/api/items",w="http://localhost:4000/api/delivery-chalans",f="http://localhost:4000/api/delivery-chalan-items",xe=()=>{const x=re(),{id:m}=ne(),{showAlert:l}=se(),p=i.useRef(null),Q=i.useRef(null),z=i.useRef(null),[I,B]=i.useState(!1),[U,C]=i.useState(!1),[c,ue]=i.useState(!!m),[g,S]=i.useState(!1),[D,E]=i.useState(""),[P,q]=i.useState(new Date().toISOString().split("T")[0]),[N,T]=i.useState(""),[he,H]=i.useState([]),[u,k]=i.useState([]),[_,b]=i.useState(""),[j,A]=i.useState(null),[h,y]=i.useState({item_id:0,item_name:"",item_code:"",quantity:1}),[F,K]=i.useState(0),M=["Party 1","Party 2","Party 3","Regular Party","New Party"],O=()=>{B(!I)};i.useEffect(()=>{W(),(async()=>{c||await V()})(),c&&m&&Y(m)},[c,m]);const L=ie();i.useEffect(()=>{const a=new URLSearchParams(L.search).get("newItemCode");a&&(b(a),(async()=>{try{const o=await d.get("http://168.231.122.33:4000/api/item-exact",{params:{code:a.trim()}});o.data&&o.data.item&&(R(o.data.item),p.current&&p.current.focus())}catch(o){console.error("Error fetching new item:",o),l("Error fetching the newly added item","error")}})(),x("/forms/delivery-chalan-form",{replace:!0}))},[L]);const V=async()=>{if(!c)try{const r=((await d.get(w)).data||[]).map(n=>n.chalan_number).filter(n=>/^\d+$/.test(n)).map(n=>parseInt(n,10)),s=(r.length>0?Math.max(...r):0)+1;E(s.toString())}catch(t){console.error("Error generating chalan number:",t),E("1")}},W=async()=>{C(!0);try{const a=(await d.get(me)).data.map(r=>(r.item_code!==void 0&&r.item_code!==null&&(r.item_code=r.item_code.toString().trim()),r));H(a),console.log(`Loaded ${a.length} items from backend API`)}catch(t){console.error("Error loading items:",t),l("Failed to load items from server","error")}finally{C(!1)}},Y=async t=>{C(!0);try{const r=(await d.get(`${w}/${t}`)).data;E(r.chalan_number),q(r.chalan_date),T(r.party_name);const s=(await d.get(`${f}?chalan_id=${t}`)).data.map(n=>({id:n.id,item_id:n.item_id,item_name:n.item_name,item_code:n.item_code||"",quantity:n.quantity}));k(s)}catch(a){console.error("Error fetching delivery chalan for editing:",a),l("Failed to load delivery chalan data","error"),x("/lists/delivery-chalan-list")}finally{C(!1)}};i.useEffect(()=>{const t=u.reduce((a,r)=>a+r.quantity,0);K(t)},[u]);const G=async t=>{const a=t.target.value.trim();b(a),a===""&&y({item_id:0,item_name:"",item_code:"",quantity:1})},J=t=>{de(t,_,a=>{var r;console.log("Exact match found on Tab/Enter:",a.item.item_name),R(a.item),t.key==="Enter"&&((r=document.getElementById("add-item-button"))==null||r.click())},a=>{console.error("Error in exact item lookup:",a),l("Item not found with this exact code","error"),y({item_id:0,item_name:"",item_code:_,quantity:1})})},R=t=>{y({item_id:t.id,item_name:t.item_name,item_code:t.item_code||"",quantity:1})},X=()=>{if(h.item_id===0){l("Please select an item","error");return}if(h.quantity<=0){l("Quantity must be greater than zero","error");return}j!==null?(k(t=>t.map(a=>a.id===j?{...h,id:j}:a)),A(null)):k(t=>[...t,{...h,id:Date.now()}]),y({item_id:0,item_name:"",item_code:"",quantity:1}),b(""),p.current&&p.current.focus()},Z=t=>{if(t){const a=u.find(r=>r.id===t);a&&(y(a),A(t),a.item_code&&b(a.item_code),p.current&&p.current.focus())}},ee=t=>{t&&(k(a=>a.filter(r=>r.id!==t)),j===t&&(A(null),y({item_id:0,item_name:"",item_code:"",quantity:1}),b("")))},te=async()=>{if(!N){l("Please select a party name","error");return}if(u.length===0){l("Please add at least one item","error");return}if(!g){S(!0);try{const t={chalan_number:D,chalan_date:P,party_name:N,total_quantity:F};let a;if(c&&m){await d.put(`${w}/${m}`,t),a=parseInt(m);const r=await d.get(`${f}?chalan_id=${a}`);for(const o of r.data)await d.delete(`${f}/${o.id}`)}else a=(await d.post(w,t)).data.id;for(const r of u){const o={chalan_id:a,item_id:r.item_id,item_name:r.item_name,item_code:r.item_code||"",quantity:r.quantity};await d.post(f,o)}l(c?"Delivery Chalan updated successfully!":"Delivery Chalan saved successfully!","success"),setTimeout(()=>{x("/lists/delivery-chalan-list")},500)}catch(t){console.error("Error saving delivery chalan:",t),l(c?"Failed to update delivery chalan":"Failed to save delivery chalan","error")}finally{S(!1)}}},ae=async()=>{if(!N){l("Please select a party name","error");return}if(u.length===0){l("Please add at least one item","error");return}if(!g){S(!0);try{const t={chalan_number:D,chalan_date:P,party_name:N,total_quantity:F};console.log("Submitting delivery chalan data:",t);let a,r={...t};if(c&&m){console.log("Updating existing chalan:",m),await d.put(`${w}/${m}`,t),a=parseInt(m),r.id=a;const n=await d.get(`${f}?chalan_id=${a}`);for(const v of n.data)await d.delete(`${f}/${v.id}`)}else{console.log("Creating new chalan with data:",t);try{const n=await d.post(w,t);console.log("API response:",n.data),a=n.data.id,r.id=a}catch(n){throw console.error("Error creating delivery chalan:",n),n.response&&(console.error("Response data:",n.response.data),console.error("Response status:",n.response.status)),n}}console.log("Saving chalan items:",u.length);for(const n of u){const v={chalan_id:a,item_id:n.item_id,item_name:n.item_name,item_code:n.item_code||"",quantity:n.quantity};console.log("Adding chalan item:",v),await d.post(f,v)}l(c?"Delivery Chalan updated successfully!":"Delivery Chalan saved successfully!","success");const o={...r,items:u},s=window.open("","_blank");s?(s.document.write("<html><head><title>Delivery Chalan</title>"),s.document.write("<style>"),s.document.write(`
          /* Print styles for Delivery Chalan */
          @page {
            size: A4;
            margin: 0.5cm;
          }
          
          body, html {
            margin: 0;
            padding: 0;
            background: white;
            font-size: 12pt;
            color: black;
            font-family: Arial, sans-serif;
          }

          /* Invoice container */
          .print-chalan {
            width: 100%;
            max-width: 100%;
            padding: 20px;
            box-sizing: border-box;
          }

          /* Chalan header */
          .print-header {
            text-align: center;
            margin-bottom: 20px;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
          }

          /* Company name */
          .company-name {
            font-size: 24pt;
            font-weight: bold;
            margin-bottom: 5px;
          }

          /* Chalan info */
          .chalan-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #000;
          }

          /* Table styles */
          .print-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
          }

          .print-table th, .print-table td {
            border: 1px solid #000;
            padding: 8px;
          }

          .print-table th {
            background-color: #f2f2f2;
            text-align: left;
            font-weight: bold;
          }

          /* Total row */
          .total-row {
            font-weight: bold;
          }

          /* Signature section */
          .signature-section {
            display: flex;
            justify-content: space-between;
            margin-top: 40px;
          }

          .signature-box {
            border-top: 1px solid #000;
            width: 200px;
            padding-top: 5px;
            text-align: center;
          }

          /* Hide page elements when printing */
          @media print {
            body {
              margin: 0;
              padding: 0;
            }
            
            .no-print {
              display: none;
            }
          }
          
          /* Print controls */
          .print-controls {
            padding: 15px;
            background-color: #f0f4f8;
            border-bottom: 1px solid #ccc;
            text-align: center;
          }
          
          .print-button {
            background-color: #4CAF50;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            margin-right: 10px;
          }
          
          .print-button:hover {
            background-color: #45a049;
          }
          
          .close-button {
            background-color: #f44336;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
          }
          
          .close-button:hover {
            background-color: #d32f2f;
          }
        `),s.document.write("</style></head><body>"),s.document.write(`
          <div class="print-controls no-print">
            <button class="print-button" onclick="window.print()">Print</button>
            <button class="close-button" onclick="window.close()">Close</button>
          </div>
        `),s.document.write(`
          <div class="print-chalan">
            <div class="print-header">
              <div class="company-name">KATHA SALES</div>
              <div>Delivery Chalan</div>
            </div>
            
            <div class="chalan-info">
              <div>
                <div><strong>Chalan Number:</strong> ${o.chalan_number}</div>
                <div><strong>Date:</strong> ${new Date(o.chalan_date).toLocaleDateString()}</div>
              </div>
              <div>
                <div><strong>Party Name:</strong> ${o.party_name}</div>
              </div>
            </div>
            
            <table class="print-table">
              <thead>
                <tr>
                  <th>Sr. No.</th>
                  <th>Item Code</th>
                  <th>Item Name</th>
                  <th>Quantity</th>
                </tr>
              </thead>
              <tbody>
                ${o.items.map((n,v)=>`
                  <tr>
                    <td>${v+1}</td>
                    <td>${n.item_code||""}</td>
                    <td>${n.item_name}</td>
                    <td>${n.quantity}</td>
                  </tr>
                `).join("")}
              </tbody>
              <tfoot>
                <tr class="total-row">
                  <td colspan="3" style="text-align: right;"><strong>Total Quantity:</strong></td>
                  <td><strong>${o.total_quantity}</strong></td>
                </tr>
              </tfoot>
            </table>
            
            <div class="signature-section">
              <div class="signature-box">Authorized Signature</div>
              <div class="signature-box">Received By</div>
            </div>
          </div>
        `),s.document.write("</body></html>"),s.document.close(),s.onafterprint=()=>{setTimeout(()=>{x("/lists/delivery-chalan-list")},500)}):(l("Could not open print window. Please check if pop-up is blocked.","error"),setTimeout(()=>{x("/lists/delivery-chalan-list")},500))}catch(t){console.error("Error saving and printing delivery chalan:",t),l(c?"Failed to update and print delivery chalan":"Failed to save and print delivery chalan","error")}finally{S(!1)}}};return U?e.jsxs("div",{className:"flex items-center justify-center h-64",children:[e.jsx("div",{className:"animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"}),e.jsx("p",{className:"ml-3 text-gray-600",children:"Loading..."})]}):e.jsxs("div",{ref:z,className:`bg-white rounded-lg shadow-md ${I?"fullscreen-form":""}`,children:[e.jsxs("div",{className:"bg-primary text-white px-6 py-4 rounded-t-lg flex justify-between items-center",children:[e.jsx("h2",{className:"text-xl font-semibold",children:c?"Edit Delivery Chalan":"New Delivery Chalan"}),e.jsx("div",{className:"flex items-center space-x-2",children:e.jsx("button",{onClick:O,className:"bg-white/20 hover:bg-white/30 text-white p-1.5 rounded-md transition-colors",title:I?"Exit Fullscreen":"Enter Fullscreen",children:I?e.jsx(oe,{className:"h-5 w-5"}):e.jsx(le,{className:"h-5 w-5"})})})]}),e.jsxs("div",{className:"p-6",children:[e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-6 mb-6",children:[e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Chalan Number"}),e.jsx("input",{type:"text",value:D,onChange:t=>E(t.target.value),className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Chalan Date"}),e.jsx("input",{type:"date",value:P,onChange:t=>q(t.target.value),className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Party Name"}),e.jsxs("select",{value:N,onChange:t=>T(t.target.value),className:"form-select w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50",children:[e.jsx("option",{value:"",children:"-- Select Party --"}),M.map((t,a)=>e.jsx("option",{value:t,children:t},a))]})]})]}),e.jsxs("div",{className:"bg-gray-50 p-4 rounded-lg mb-6",children:[e.jsx("h3",{className:"text-lg font-medium text-gray-700 mb-4",children:"Item Details"}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-12 gap-3 mb-5",children:[e.jsxs("div",{className:"md:col-span-6 relative",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Item Code"}),e.jsxs("div",{className:"flex",children:[e.jsx("input",{ref:p,type:"text",value:_,onChange:G,onKeyDown:J,className:`form-input w-full rounded-l-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50 ${h.item_id?"border-green-500":_&&!h.item_id?"border-red-500":""}`,placeholder:"Enter item code or barcode"}),e.jsx("button",{type:"button",onClick:()=>{window.open("http://localhost:5173/forms/item?returnTo=delivery","_blank");const t=a=>{if(a.data&&a.data.newItemCode){const r=a.data.newItemCode;b(r),(async()=>{try{const s=await d.get("http://168.231.122.33:4000/api/item-exact",{params:{code:r.trim()}});s.data&&s.data.item&&(R(s.data.item),p.current&&p.current.focus())}catch(s){console.error("Error fetching new item:",s),l("Error fetching the newly added item","error")}})(),window.removeEventListener("message",t)}};window.addEventListener("message",t)},className:"bg-green-600 text-white px-3 rounded-r-md hover:bg-green-700 flex items-center justify-center",title:"Add New Item",children:e.jsx(ce,{className:"h-5 w-5"})})]}),_&&!h.item_id&&e.jsx("p",{className:"text-xs text-red-500 mt-1",children:"Item not found. Try adding it."})]}),e.jsxs("div",{className:"md:col-span-4",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Item Name"}),e.jsx("input",{type:"text",value:h.item_name,readOnly:!0,className:"form-input w-full rounded-md border-gray-300 bg-gray-100 shadow-sm"})]}),e.jsxs("div",{className:"md:col-span-2",children:[e.jsx("label",{className:"block text-sm font-medium text-gray-700 mb-1",children:"Quantity"}),e.jsx("input",{type:"number",min:"1",value:h.quantity,onChange:t=>{const a=parseInt(t.target.value)||0;y({...h,quantity:a})},className:"form-input w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring focus:ring-primary focus:ring-opacity-50"})]})]}),e.jsx("div",{className:"flex justify-end",children:e.jsx($,{id:"add-item-button",onClick:X,className:"bg-primary text-white px-6 py-2 rounded-md hover:bg-primary-dark transition-colors",children:j!==null?"Update Item":"Add Item"})})]}),e.jsx("div",{className:"mb-6 overflow-x-auto",children:e.jsxs("table",{className:"w-full border-collapse",children:[e.jsx("thead",{children:e.jsxs("tr",{className:"bg-gray-100",children:[e.jsx("th",{className:"py-2 px-4 text-left border",children:"Item Code"}),e.jsx("th",{className:"py-2 px-4 text-left border",children:"Item Name"}),e.jsx("th",{className:"py-2 px-4 text-right border",children:"Quantity"}),e.jsx("th",{className:"py-2 px-4 text-center border",children:"Actions"})]})}),e.jsx("tbody",{children:u.length===0?e.jsx("tr",{children:e.jsx("td",{colSpan:4,className:"py-4 text-center text-gray-500 border",children:"No items added yet. Use the form above to add items."})}):u.map(t=>e.jsxs("tr",{className:"hover:bg-gray-50",children:[e.jsx("td",{className:"py-2 px-4 border",children:t.item_code}),e.jsx("td",{className:"py-2 px-4 border",children:t.item_name}),e.jsx("td",{className:"py-2 px-4 text-right border",children:t.quantity}),e.jsxs("td",{className:"py-2 px-4 text-center border",children:[e.jsx("button",{onClick:()=>Z(t.id),className:"text-blue-600 hover:text-blue-800 mr-2",children:"Edit"}),e.jsx("button",{onClick:()=>ee(t.id),className:"text-red-600 hover:text-red-800",children:"Delete"})]})]},t.id))}),e.jsx("tfoot",{children:e.jsxs("tr",{className:"bg-gray-100 font-medium",children:[e.jsx("td",{colSpan:2,className:"text-right pr-4 py-2 border",children:"Total Quantity:"}),e.jsx("td",{className:"text-right pr-4 border",children:F}),e.jsx("td",{className:"border"})]})})]})}),e.jsxs("div",{className:"flex justify-end space-x-4",children:[e.jsx($,{onClick:()=>x("/lists/delivery-chalan-list"),className:"bg-gray-200 text-gray-700 px-6 py-2 rounded-md hover:bg-gray-300 transition-colors",children:"Cancel"}),e.jsx($,{onClick:te,disabled:g,className:`bg-green-600 text-white px-6 py-2 rounded-md transition-colors ${g?"opacity-70 cursor-not-allowed":"hover:bg-green-700 cursor-pointer"}`,children:g?"Saving...":c?"Update":"Save"}),e.jsx($,{onClick:ae,disabled:g,className:`bg-blue-600 text-white px-6 py-2 rounded-md transition-colors ${g?"opacity-70 cursor-not-allowed":"hover:bg-blue-700 cursor-pointer"}`,children:g?"Processing...":"Save & Print"})]})]}),e.jsx("div",{ref:Q,className:"hidden"})]})};export{xe as default};
