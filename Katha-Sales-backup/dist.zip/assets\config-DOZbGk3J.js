const s="http://localhost:4000",a={ITEMS:`${s}/api/items`,CASHSALES:`${s}/api/cashsales`,CASHSALE_ITEMS:`${s}/api/cashsale-items`};export{a as A};
